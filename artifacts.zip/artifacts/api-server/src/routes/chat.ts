import { Router, type IRouter, type Request, type Response } from "express";
import { openai, OpenAI } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

type TextPart = { type: "text"; text: string };
type ImagePart = {
  type: "image_url";
  image_url: { url: string; detail?: "low" | "high" | "auto" };
};
type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string | Array<TextPart | ImagePart>;
};

type ChatBody = {
  message?: string;
  history?: Array<{ role: "user" | "assistant"; content: string }>;
  subject?: string;
  level?: string;
  teachingStyle?: string;
  language?: string;
  studentName?: string;
  apiKey?: string;
  images?: string[];
  dataSaver?: boolean;
};

function getClient(apiKey?: string): { client: OpenAI; model: string } {
  const trimmed = (apiKey ?? "").trim();
  if (trimmed) {
    return { client: new OpenAI({ apiKey: trimmed }), model: "gpt-4o" };
  }
  return { client: openai, model: "gpt-5.4" };
}

const TEACHING_STYLE_PROMPTS: Record<string, string> = {
  Friendly:
    "Be warm, encouraging, and conversational. Use everyday analogies. Celebrate small wins.",
  Strict:
    "Be precise, formal, and demanding of rigor. Correct mistakes directly. Push for full reasoning.",
  Socratic:
    "Never give the answer immediately. Ask guiding questions that lead the student to discover the answer themselves.",
  "Exam Coach":
    "Focus on exam technique, mark schemes, and how to structure answers for maximum marks. Reference common pitfalls.",
};

function buildSystemPrompt(body: ChatBody): string {
  const style = body.teachingStyle ?? "Friendly";
  const styleNote = TEACHING_STYLE_PROMPTS[style] ?? TEACHING_STYLE_PROMPTS["Friendly"];
  const subject = body.subject ?? "general studies";
  const level = body.level ?? "Grade 12";
  const language = body.language ?? "English";
  const name = body.studentName?.trim() || "the student";

  const lines = [
    "You are Thinkr, an AI study companion for South African learners following the CAPS curriculum (and NQF levels for tertiary learners).",
    `You are tutoring ${name} on ${subject} at the ${level} level.`,
    `Respond primarily in ${language}, but you may include key technical terms in English when appropriate.`,
    "Always tie explanations back to CAPS curriculum outcomes when relevant.",
    "Use clear markdown: short paragraphs, bullet points, numbered steps for worked examples, and LaTeX-free math written as plain text.",
    "When teaching a concept, follow this structure: (1) one-line intuition, (2) the core rule or formula, (3) a worked example, (4) a quick check question for the student.",
    "Keep answers focused — avoid walls of text. If a topic is large, break it into a first chunk and offer to go deeper.",
    `Teaching style — ${style}: ${styleNote}`,
    "Never claim to be ChatGPT or OpenAI. You are Thinkr.",
  ];

  if (body.dataSaver) {
    lines.push(
      "DATA SAVER MODE IS ON. The student is on a limited mobile data plan. Be extremely concise: keep your full reply under 120 words. Use short bullet points. Skip greetings, sign-offs, and restating the question. No emojis. No long preambles. Cut the worked example to the bare minimum needed.",
    );
  }

  return lines.join("\n");
}

router.post("/chat/stream", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as ChatBody;
  const message = (body.message ?? "").toString().trim();

  if (!message) {
    res.status(400).json({ error: "message is required" });
    return;
  }

  const dataSaver = body.dataSaver === true;
  const historyLimit = dataSaver ? 6 : 12;
  const imageLimit = dataSaver ? 1 : 4;
  const history = Array.isArray(body.history)
    ? body.history.slice(-historyLimit)
    : [];
  const images = Array.isArray(body.images)
    ? body.images
        .filter((u): u is string => typeof u === "string" && u.startsWith("data:image/"))
        .slice(0, imageLimit)
    : [];

  // Build user message content. If images present, use multimodal content array.
  // In data-saver mode, request "low" detail so vision processing uses fewer tokens.
  const userContent: ChatMessage["content"] =
    images.length > 0
      ? [
          { type: "text", text: message },
          ...images.map(
            (url): ImagePart => ({
              type: "image_url",
              image_url: dataSaver
                ? { url, detail: "low" }
                : { url },
            }),
          ),
        ]
      : message;

  const messages: ChatMessage[] = [
    { role: "system", content: buildSystemPrompt(body) },
    ...history
      .filter(
        (m): m is { role: "user" | "assistant"; content: string } =>
          !!m &&
          (m.role === "user" || m.role === "assistant") &&
          typeof m.content === "string",
      )
      .map((m) => ({ role: m.role, content: m.content }) as ChatMessage),
    { role: "user", content: userContent },
  ];

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();

  const { client, model } = getClient(body.apiKey);

  try {
    const stream = await client.chat.completions.create({
      model,
      max_completion_tokens: dataSaver ? 600 : 8192,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      messages: messages as any,
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log?.error?.({ err }, "chat stream failed");
    try {
      res.write(
        `data: ${JSON.stringify({
          error: "I had trouble generating a response. Please try again.",
        })}\n\n`,
      );
      res.end();
    } catch {
      // socket already closed
    }
  }
});

router.post("/chat/past-paper", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subject?: string;
    level?: string;
    topic?: string;
    language?: string;
    marks?: number;
  };

  const subject = body.subject ?? "Mathematics";
  const level = body.level ?? "Grade 12";
  const topic = body.topic?.trim() || "any major topic from the CAPS curriculum";
  const language = body.language ?? "English";
  const marks = Math.max(2, Math.min(20, Number(body.marks) || 6));

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 2000,
      messages: [
        {
          role: "system",
          content:
            "You are a CAPS curriculum past-paper writer for South African schools and tertiary modules. You produce a single exam-style question that a teacher would actually set in a paper. Reply ONLY with valid minified JSON: {\"question\":string,\"marks\":number,\"markScheme\":string,\"modelAnswer\":string,\"tips\":string}. The markScheme should describe per-mark allocation. The modelAnswer should be a concise full-mark answer. Tips should be a short paragraph on exam technique for this kind of question.",
        },
        {
          role: "user",
          content: `Subject: ${subject}\nLevel: ${level}\nTopic: ${topic}\nLanguage of question and answers: ${language}\nMarks: ${marks}\nGenerate one exam-style question worth ${marks} marks.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    if (!parsed.question || !parsed.markScheme || !parsed.modelAnswer) {
      res.status(502).json({ error: "Invalid past-paper response from model" });
      return;
    }
    res.json({
      question: String(parsed.question),
      marks: Number(parsed.marks) || marks,
      markScheme: String(parsed.markScheme),
      modelAnswer: String(parsed.modelAnswer),
      tips: String(parsed.tips ?? ""),
    });
  } catch (err) {
    req.log?.error?.({ err }, "past paper generation failed");
    res.status(500).json({ error: "Failed to generate past paper question" });
  }
});

router.post("/chat/grade-answer", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subject?: string;
    level?: string;
    language?: string;
    question?: string;
    markScheme?: string;
    marks?: number;
    studentAnswer?: string;
  };

  const subject = body.subject ?? "Mathematics";
  const level = body.level ?? "Grade 12";
  const language = body.language ?? "English";
  const question = (body.question ?? "").toString().trim();
  const markScheme = (body.markScheme ?? "").toString().trim();
  const studentAnswer = (body.studentAnswer ?? "").toString().trim();
  const marks = Math.max(1, Math.min(50, Number(body.marks) || 6));

  if (!question || !studentAnswer) {
    res.status(400).json({ error: "question and studentAnswer are required" });
    return;
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 2000,
      messages: [
        {
          role: "system",
          content:
            "You are a fair, encouraging CAPS curriculum exam marker for South African students. Mark the student's answer using the provided mark scheme. Reply ONLY with valid minified JSON: {\"marksAwarded\":number,\"feedback\":string,\"strengths\":string[],\"improvements\":string[]}. The feedback should be 2-4 short paragraphs in the student's language. strengths and improvements should each be 1-3 short bullet points. Be honest but kind.",
        },
        {
          role: "user",
          content: `Subject: ${subject}\nLevel: ${level}\nLanguage: ${language}\nTotal marks: ${marks}\n\nQuestion:\n${question}\n\nMark scheme:\n${markScheme}\n\nStudent's answer:\n${studentAnswer}\n\nMark this answer.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    res.json({
      marksAwarded: Math.max(0, Math.min(marks, Number(parsed.marksAwarded) || 0)),
      totalMarks: marks,
      feedback: String(parsed.feedback ?? ""),
      strengths: Array.isArray(parsed.strengths) ? parsed.strengths.map(String) : [],
      improvements: Array.isArray(parsed.improvements)
        ? parsed.improvements.map(String)
        : [],
    });
  } catch (err) {
    req.log?.error?.({ err }, "answer grading failed");
    res.status(500).json({ error: "Failed to grade answer" });
  }
});

router.post("/chat/flashcards", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subject?: string;
    level?: string;
    topic?: string;
    language?: string;
    count?: number;
  };

  const subject = body.subject ?? "Mathematics";
  const level = body.level ?? "Grade 12";
  const topic = body.topic?.trim() || "core concepts from the CAPS curriculum";
  const language = body.language ?? "English";
  const count = Math.max(3, Math.min(20, Number(body.count) || 8));

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 3000,
      messages: [
        {
          role: "system",
          content:
            "You generate study flashcards for South African students following the CAPS curriculum. Reply ONLY with valid minified JSON: {\"cards\":[{\"front\":string,\"back\":string,\"hint\":string}]}. Each front is a short prompt or question. Each back is a concise answer (1-3 sentences or a short formula/definition). The hint is one short helpful nudge.",
        },
        {
          role: "user",
          content: `Subject: ${subject}\nLevel: ${level}\nTopic: ${topic}\nLanguage: ${language}\nGenerate exactly ${count} flashcards.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    const cards = Array.isArray(parsed.cards) ? parsed.cards : [];
    res.json({
      cards: cards
        .filter((c: { front?: string; back?: string }) => c && c.front && c.back)
        .map((c: { front: string; back: string; hint?: string }) => ({
          front: String(c.front),
          back: String(c.back),
          hint: String(c.hint ?? ""),
        })),
    });
  } catch (err) {
    req.log?.error?.({ err }, "flashcard generation failed");
    res.status(500).json({ error: "Failed to generate flashcards" });
  }
});

router.post("/chat/study-plan", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subjects?: string[];
    level?: string;
    language?: string;
    daysUntilExam?: number;
    minutesPerDay?: number;
    goals?: string;
  };

  const subjects = Array.isArray(body.subjects) && body.subjects.length > 0
    ? body.subjects.map(String).slice(0, 8)
    : ["Mathematics"];
  const level = body.level ?? "Grade 12";
  const language = body.language ?? "English";
  const daysUntilExam = Math.max(1, Math.min(120, Number(body.daysUntilExam) || 14));
  const minutesPerDay = Math.max(15, Math.min(360, Number(body.minutesPerDay) || 60));
  const goals = body.goals?.trim() || "general revision and consolidation";

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 3000,
      messages: [
        {
          role: "system",
          content:
            "You are a CAPS-aware study planner for South African students. Build a realistic day-by-day study plan. Reply ONLY with valid minified JSON: {\"summary\":string,\"days\":[{\"day\":number,\"date\":string,\"focus\":string,\"blocks\":[{\"subject\":string,\"topic\":string,\"minutes\":number,\"activity\":string}]}]}. The summary is a short encouraging paragraph. Use ISO date strings (YYYY-MM-DD) starting from today.",
        },
        {
          role: "user",
          content: `Today is ${new Date().toISOString().split("T")[0]}.\nLevel: ${level}\nLanguage: ${language}\nSubjects in scope: ${subjects.join(", ")}\nDays until exam/test: ${daysUntilExam}\nMinutes available per day: ${minutesPerDay}\nGoals: ${goals}\n\nBuild a ${daysUntilExam}-day study plan. Cap individual day plans to ${minutesPerDay} minutes total. Mix subjects sensibly. Include short activities like "active recall", "past paper question", "flashcards", "concept review".`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    res.json({
      summary: String(parsed.summary ?? ""),
      days: Array.isArray(parsed.days) ? parsed.days : [],
    });
  } catch (err) {
    req.log?.error?.({ err }, "study plan generation failed");
    res.status(500).json({ error: "Failed to generate study plan" });
  }
});

const CAPS_REFERENCE_SOURCES = [
  {
    name: "DBE Official",
    hosts: ["education.gov.za", "www.education.gov.za"],
    canonicalUrl:
      "https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS).aspx",
  },
  {
    name: "WCED ePortal",
    hosts: ["wcedeportal.co.za", "www.wcedeportal.co.za"],
    canonicalUrl:
      "https://wcedeportal.co.za/curriculum-assessment-policy-statements",
  },
  {
    name: "SAQA",
    hosts: ["saqa.org.za", "www.saqa.org.za"],
    canonicalUrl: "https://saqa.org.za/national-qualifications-framework/",
  },
] as const;

const CAPS_PATTERN = /CAPS\s+[A-Za-z\s]+Grade\s+\d+/i;
const NQF_PATTERN = /NQF\s+Level\s+\d+/i;

function verifyReferenceSource(
  sourceUrl: string,
  capsRef: string,
  nqfRef: string,
): string {
  if (sourceUrl) {
    try {
      const host = new URL(sourceUrl).hostname.toLowerCase();
      const match = CAPS_REFERENCE_SOURCES.find((s) =>
        s.hosts.some((h) => host === h),
      );
      if (match) return match.name;
    } catch {
      // fall through
    }
  }
  if (capsRef && CAPS_PATTERN.test(capsRef)) return "Format match";
  if (nqfRef && NQF_PATTERN.test(nqfRef)) return "Format match";
  return "";
}

router.post("/chat/foundations", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    question?: string;
    subject?: string;
    level?: string;
    language?: string;
    dataSaver?: boolean;
  };

  const question = (body.question ?? "").toString().trim();
  const subject = body.subject ?? "Mathematics";
  const level = body.level ?? "Grade 12";
  const language = body.language ?? "English";
  const dataSaver = body.dataSaver === true;

  if (!question) {
    res.status(400).json({ error: "question is required" });
    return;
  }

  const allowedHosts = CAPS_REFERENCE_SOURCES.flatMap((s) => s.hosts).join(", ");
  const sourceList = CAPS_REFERENCE_SOURCES.map(
    (s) => `- ${s.name}: ${s.canonicalUrl}`,
  ).join("\n");

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: dataSaver ? 1500 : 3500,
      messages: [
        {
          role: "system",
          content:
            `You map prerequisite knowledge for South African CAPS-curriculum students and cite official Department of Basic Education (DBE), WCED, and SAQA sources. Given a student's question and their current grade/NQF level, identify 3-6 foundational concepts from EARLIER grades that they need to master in order to fully understand the question. Each foundation must be from a strictly lower grade or NQF level than the student's current level.\n\nReply ONLY with valid minified JSON: {"concepts":string[],"foundations":[{"concept":string,"fromLevel":string,"type":"formula"|"concept"|"example"|"rule","title":string,"explanation":string,"example":string,"capsRef":string,"nqfRef":string,"sourceUrl":string}]}. concepts is a 1-3 item list of the core concepts in the question. For each foundation: title is short (under 8 words); explanation is 2-4 sentences in plain language in the student's home language; example is one short worked example or analogy; capsRef cites the relevant CAPS document section in the form "CAPS <Subject> <Grade>, Section <X.Y>" — do NOT invent page numbers; nqfRef cites the NQF descriptor in the form "NQF Level <N>, Outcome <X.Y>" or "" if not applicable.\n\nFor sourceUrl, ONLY use a URL whose host is one of: ${allowedHosts}. Prefer these canonical landing pages:\n${sourceList}\nIf you cannot point to one of these, return "" for sourceUrl. Be conservative — only include refs you are confident about; use "" for unknown fields.`,
        },
        {
          role: "user",
          content: `Subject: ${subject}\nStudent's current level: ${level}\nLanguage: ${language}\n\nStudent's question:\n${question}\n\nList the foundational building blocks from earlier grades that this student needs to know, with CAPS/NQF citations where you are confident.${dataSaver ? "\n\nDATA SAVER MODE: return only 3 foundations. Keep each explanation to ONE short sentence and each example to one line." : ""}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw);
    const safeUrl = (u: unknown): string => {
      if (typeof u !== "string" || !u) return "";
      try {
        const parsedUrl = new URL(u);
        if (parsedUrl.protocol === "http:" || parsedUrl.protocol === "https:") {
          return parsedUrl.toString();
        }
        return "";
      } catch {
        return "";
      }
    };

    res.json({
      concepts: Array.isArray(parsed.concepts) ? parsed.concepts.map(String) : [],
      foundations: Array.isArray(parsed.foundations)
        ? parsed.foundations
            .filter(
              (f: { concept?: string; explanation?: string }) =>
                f && f.concept && f.explanation,
            )
            .map(
              (f: {
                concept: string;
                fromLevel?: string;
                type?: string;
                title?: string;
                explanation: string;
                example?: string;
                capsRef?: string;
                nqfRef?: string;
                sourceUrl?: string;
              }) => {
                const capsRef = String(f.capsRef ?? "");
                const nqfRef = String(f.nqfRef ?? "");
                const sourceUrl = safeUrl(f.sourceUrl);
                return {
                  concept: String(f.concept),
                  fromLevel: String(f.fromLevel ?? ""),
                  type: String(f.type ?? "concept"),
                  title: String(f.title ?? f.concept),
                  explanation: String(f.explanation),
                  example: String(f.example ?? ""),
                  capsRef,
                  nqfRef,
                  sourceUrl,
                  verifiedSource: verifyReferenceSource(sourceUrl, capsRef, nqfRef),
                };
              },
            )
        : [],
      curriculum: "CAPS",
      sources: CAPS_REFERENCE_SOURCES.map((s) => ({
        name: s.name,
        url: s.canonicalUrl,
      })),
    });
  } catch (err) {
    req.log?.error?.({ err }, "foundations generation failed");
    res.status(500).json({ error: "Failed to find foundations" });
  }
});

router.post("/chat/quiz", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subject?: string;
    level?: string;
    topic?: string;
    language?: string;
  };

  const subject = body.subject ?? "Mathematics";
  const level = body.level ?? "Grade 12";
  const topic = body.topic?.trim() || "a core topic from the CAPS curriculum";
  const language = body.language ?? "English";

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 1500,
      messages: [
        {
          role: "system",
          content:
            "You generate one short multiple-choice CAPS-aligned quiz question. Reply ONLY with valid minified JSON matching this TypeScript type: {\"question\":string,\"choices\":string[],\"answerIndex\":number,\"explanation\":string}. Provide exactly 4 choices. answerIndex is 0-based.",
        },
        {
          role: "user",
          content: `Subject: ${subject}\nLevel: ${level}\nTopic: ${topic}\nLanguage: ${language}\nGenerate one challenging but fair CAPS-aligned multiple-choice question.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw) as {
      question?: string;
      choices?: string[];
      answerIndex?: number;
      explanation?: string;
    };

    if (
      !parsed.question ||
      !Array.isArray(parsed.choices) ||
      parsed.choices.length < 2 ||
      typeof parsed.answerIndex !== "number"
    ) {
      res.status(502).json({ error: "Invalid quiz response from model" });
      return;
    }

    res.json({
      question: parsed.question,
      choices: parsed.choices,
      answerIndex: parsed.answerIndex,
      explanation: parsed.explanation ?? "",
    });
  } catch (err) {
    req.log?.error?.({ err }, "quiz generation failed");
    res.status(500).json({ error: "Failed to generate quiz" });
  }
});

export default router;
