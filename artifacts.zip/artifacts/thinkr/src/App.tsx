import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";

import Home from "@/pages/home";
import Chat from "@/pages/chat";
import Progress from "@/pages/progress";
import Dashboard from "@/pages/dashboard";
import Settings from "@/pages/settings";
import PastPapers from "@/pages/past-papers";
import Voice from "@/pages/voice";
import Planner from "@/pages/planner";
import Flashcards from "@/pages/flashcards";
import Boosters from "@/pages/boosters";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chat" component={Chat} />
      <Route path="/voice" component={Voice} />
      <Route path="/past-papers" component={PastPapers} />
      <Route path="/flashcards" component={Flashcards} />
      <Route path="/planner" component={Planner} />
      <Route path="/boosters" component={Boosters} />
      <Route path="/progress" component={Progress} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Layout>
            <Router />
          </Layout>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
