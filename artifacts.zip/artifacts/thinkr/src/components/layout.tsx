import { Link, useLocation } from "wouter";
import { useProfile } from "@/lib/store";
import {
  BookOpen,
  LayoutDashboard,
  MessageSquare,
  Settings,
  TrendingUp,
  ScrollText,
  Headphones,
  CalendarClock,
  Layers,
  Brain,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const profile = useProfile();
  const [location] = useLocation();

  if (!profile.hasOnboarded) {
    return <main className="min-h-[100dvh] w-full bg-background">{children}</main>;
  }

  const primaryNav = [
    { href: "/", label: "Home", icon: BookOpen },
    { href: "/chat", label: "Tutor", icon: MessageSquare },
    { href: "/voice", label: "Voice", icon: Headphones },
    { href: "/progress", label: "Progress", icon: TrendingUp },
    { href: "/dashboard", label: "Stats", icon: LayoutDashboard },
  ];

  const secondaryNav = [
    { href: "/past-papers", label: "Past papers", icon: ScrollText },
    { href: "/flashcards", label: "Flashcards", icon: Layers },
    { href: "/planner", label: "Planner", icon: CalendarClock },
    { href: "/boosters", label: "Boosters", icon: Brain },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  const navItems = [...primaryNav, ...secondaryNav];

  return (
    <div className="min-h-[100dvh] w-full flex flex-col md:flex-row bg-background">
      {/* Mobile bottom nav: primary items only (5) */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 flex h-16 items-center justify-around border-t bg-card px-2 md:hidden">
        {primaryNav.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors flex-1",
                isActive
                  ? "text-primary font-medium"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-[10px]">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Desktop sidebar: full nav */}
      <nav className="hidden md:flex md:relative md:h-auto md:w-64 md:flex-col md:justify-start md:border-r md:px-4 md:py-8 bg-card overflow-y-auto">
        <div className="flex w-full items-center gap-2 px-2 pb-6 mb-4 border-b">
          <div className="bg-primary text-primary-foreground p-2 rounded-xl">
            <BookOpen className="h-6 w-6" />
          </div>
          <span className="text-xl font-bold font-sans tracking-tight">Thinkr</span>
        </div>

        <div className="flex w-full flex-col gap-1">
          <p className="px-3 text-[10px] uppercase tracking-wider text-muted-foreground mt-1 mb-1">
            Study
          </p>
          {primaryNav.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm relative hover:bg-muted",
                  isActive
                    ? "text-primary bg-primary/10 font-medium"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <item.icon
                  className={cn("h-4 w-4", isActive && "text-primary")}
                />
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute right-2 w-1.5 h-1.5 rounded-full bg-primary" />
                )}
              </Link>
            );
          })}

          <p className="px-3 text-[10px] uppercase tracking-wider text-muted-foreground mt-4 mb-1">
            Tools
          </p>
          {secondaryNav.map((item) => {
            const isActive = location === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-sm relative hover:bg-muted",
                  isActive
                    ? "text-primary bg-primary/10 font-medium"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <item.icon
                  className={cn("h-4 w-4", isActive && "text-primary")}
                />
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute right-2 w-1.5 h-1.5 rounded-full bg-primary" />
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      <main className="flex-1 pb-20 md:pb-0 overflow-y-auto">
        <div className="max-w-5xl mx-auto p-4 md:p-8">{children}</div>
      </main>
    </div>
  );
}
