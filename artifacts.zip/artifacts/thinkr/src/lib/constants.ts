export const EDUCATION_CATEGORIES = [
  { value: 'Foundation/Intermediate', label: 'Foundation & Intermediate Phase (Grades 4-7)' },
  { value: 'Senior/FET', label: 'Senior & FET Phase (Grades 8-12)' },
  { value: 'Tertiary', label: 'Tertiary (NQF 5-10)' }
];

export const GRADES = {
  'Foundation/Intermediate': ['Grade 4', 'Grade 5', 'Grade 6', 'Grade 7'],
  'Senior/FET': ['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'],
  'Tertiary': ['Higher Certificate (NQF 5)', 'Diploma (NQF 6)', 'Bachelor\'s (NQF 7)', 'Honours (NQF 8)', 'Master\'s (NQF 9)', 'Doctorate (NQF 10)']
};

export const SUBJECTS = {
  'Foundation/Intermediate': [
    'Mathematics', 'English Home Language', 'English First Additional', 
    'Afrikaans', 'isiZulu', 'isiXhosa', 'Sesotho', 
    'Natural Sciences & Technology', 'Social Sciences', 'Life Skills'
  ],
  'Senior/FET': [
    'Mathematics', 'Mathematical Literacy', 'Physical Sciences', 'Life Sciences',
    'English', 'Afrikaans', 'isiZulu', 'isiXhosa', 'History', 'Geography',
    'Accounting', 'Business Studies', 'Economics', 'Computer Applications Technology (CAT)',
    'Information Technology (IT)', 'Life Orientation', 'Engineering Graphics & Design',
    'Tourism', 'Consumer Studies'
  ]
};

export const LANGUAGES = [
  'English', 'Afrikaans', 'isiZulu', 'isiXhosa', 'Sesotho', 
  'Setswana', 'Sepedi', 'Tshivenda', 'Xitsonga', 'siSwati', 'isiNdebele'
];

export const TEACHING_STYLES = [
  { value: 'Friendly', label: 'Friendly', description: 'Like a smart older sibling explaining things patiently.' },
  { value: 'Strict', label: 'Strict', description: 'Direct and to the point. No fluff, just facts.' },
  { value: 'Socratic', label: 'Socratic', description: 'Guides you to the answer by asking you questions.' },
  { value: 'Exam Coach', label: 'Exam Coach', description: 'Focused heavily on past papers, memorisation, and test technique.' }
];

export const BADGE_DETAILS: Record<string, { description: string; icon: string }> = {
  'First Question': { description: 'Asked your very first question.', icon: 'Star' },
  '3-Day Streak': { description: 'Studied for 3 days in a row.', icon: 'Flame' },
  '7-Day Streak': { description: 'Studied for a full week!', icon: 'Flame' },
  'Subject Explorer': { description: 'Tried out 3 different subjects.', icon: 'Compass' },
  'Quiz Whiz': { description: 'Got 5 quiz questions correct.', icon: 'Award' },
  'Centurion': { description: 'Earned 100 XP.', icon: 'Zap' },
  'Marathon': { description: 'Earned 1000 XP.', icon: 'Trophy' },
  'Polyglot': { description: 'Studied in multiple languages.', icon: 'Languages' },
  'Card Sharp': { description: 'Created your first flashcard deck.', icon: 'Layers' },
  'Deep Focus': { description: 'Completed 5 focus sessions.', icon: 'Timer' },
  'Exam Ready': { description: 'Marked 3 past-paper answers.', icon: 'GraduationCap' },
};

export const API_BASE = `${import.meta.env.BASE_URL}api`;
