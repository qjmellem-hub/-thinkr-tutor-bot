import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type EducationCategory = 'Foundation/Intermediate' | 'Senior/FET' | 'Tertiary';

export interface Profile {
  name: string;
  category: EducationCategory | '';
  level: string;
  language: string;
  teachingStyle: string;
  hasOnboarded: boolean;
  apiKey: string;
  dataSaver: boolean;
}

export interface SubjectProgress {
  mastery: number; // 0-100
  xp: number;
  lastStudied: number; // timestamp
}

export interface StudySession {
  id: string;
  timestamp: number;
  subject: string;
  topic: string;
  durationMinutes: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  hint: string;
  // Spaced repetition (SM-2-lite)
  ease: number; // 1.3 - 2.5
  interval: number; // days
  due: number; // timestamp
  reps: number;
}

export interface FlashcardDeck {
  id: string;
  subject: string;
  topic: string;
  language: string;
  level: string;
  createdAt: number;
  cards: Flashcard[];
}

export interface PlannerBlock {
  subject: string;
  topic: string;
  minutes: number;
  activity: string;
  done: boolean;
}

export interface PlannerDay {
  day: number;
  date: string;
  focus: string;
  blocks: PlannerBlock[];
}

export interface StudyPlan {
  id: string;
  createdAt: number;
  level: string;
  language: string;
  subjects: string[];
  goals: string;
  daysUntilExam: number;
  minutesPerDay: number;
  summary: string;
  days: PlannerDay[];
}

export interface FocusSession {
  id: string;
  timestamp: number;
  durationMinutes: number;
  subject: string;
}

export interface PastPaperAttempt {
  id: string;
  timestamp: number;
  subject: string;
  level: string;
  topic: string;
  language: string;
  question: string;
  marks: number;
  markScheme: string;
  modelAnswer: string;
  tips: string;
  studentAnswer?: string;
  marksAwarded?: number;
  feedback?: string;
  strengths?: string[];
  improvements?: string[];
}

interface AppState {
  profile: Profile;
  progress: Record<string, SubjectProgress>;
  sessions: StudySession[];
  badges: string[];
  totalXp: number;
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string; // YYYY-MM-DD
  chatHistory: Record<string, ChatMessage[]>; // keyed by subject
  quizCorrect: number;
  languagesUsed: string[];

  // New feature state
  flashcardDecks: FlashcardDeck[];
  studyPlan: StudyPlan | null;
  focusSessions: FocusSession[];
  pastPaperAttempts: PastPaperAttempt[];
  sleepReviewEnabled: boolean;

  // Actions
  updateProfile: (profile: Partial<Profile>) => void;
  addXp: (amount: number, subject: string) => void;
  addSession: (session: StudySession) => void;
  resetProgress: () => void;
  addChatMessage: (subject: string, message: ChatMessage) => void;
  clearChatHistory: (subject: string) => void;
  recordQuizCorrect: () => void;
  trackLanguage: (lang: string) => void;

  saveFlashcardDeck: (deck: FlashcardDeck) => void;
  deleteFlashcardDeck: (id: string) => void;
  reviewFlashcard: (deckId: string, cardId: string, quality: 0 | 1 | 2 | 3) => void;

  setStudyPlan: (plan: StudyPlan | null) => void;
  togglePlannerBlock: (dayIndex: number, blockIndex: number) => void;

  addFocusSession: (s: FocusSession) => void;
  setSleepReview: (on: boolean) => void;

  addPastPaperAttempt: (a: PastPaperAttempt) => void;
  updatePastPaperAttempt: (id: string, patch: Partial<PastPaperAttempt>) => void;
}

const defaultProfile: Profile = {
  name: '',
  category: '',
  level: '',
  language: 'English',
  teachingStyle: 'Friendly',
  hasOnboarded: false,
  apiKey: '',
  dataSaver: true,
};

const checkBadges = (state: AppState): string[] => {
  const newBadges = new Set(state.badges);

  if (state.totalXp > 0) newBadges.add('First Question');
  if (state.currentStreak >= 3) newBadges.add('3-Day Streak');
  if (state.currentStreak >= 7) newBadges.add('7-Day Streak');
  if (Object.keys(state.progress).length >= 3) newBadges.add('Subject Explorer');
  if (state.totalXp >= 100) newBadges.add('Centurion');
  if (state.totalXp >= 1000) newBadges.add('Marathon');
  if (state.quizCorrect >= 5) newBadges.add('Quiz Whiz');
  if (state.languagesUsed.length >= 2) newBadges.add('Polyglot');
  if (state.flashcardDecks.length >= 1) newBadges.add('Card Sharp');
  if (state.focusSessions.length >= 5) newBadges.add('Deep Focus');
  if (state.pastPaperAttempts.filter((a) => a.marksAwarded !== undefined).length >= 3)
    newBadges.add('Exam Ready');

  return Array.from(newBadges);
};

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      profile: defaultProfile,
      progress: {},
      sessions: [],
      badges: [],
      totalXp: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastStudyDate: '',
      chatHistory: {},
      quizCorrect: 0,
      languagesUsed: [],

      flashcardDecks: [],
      studyPlan: null,
      focusSessions: [],
      pastPaperAttempts: [],
      sleepReviewEnabled: false,

      updateProfile: (updates) =>
        set((state) => {
          const next = { ...state, profile: { ...state.profile, ...updates } };
          if (updates.language && !state.languagesUsed.includes(updates.language)) {
            next.languagesUsed = [...state.languagesUsed, updates.language];
          }
          return { ...next, badges: checkBadges(next) };
        }),

      addXp: (amount, subject) =>
        set((state) => {
          const today = new Date().toISOString().split('T')[0];
          let newStreak = state.currentStreak;

          if (state.lastStudyDate !== today) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = yesterday.toISOString().split('T')[0];
            newStreak = state.lastStudyDate === yesterdayStr ? newStreak + 1 : 1;
          }

          const subjectProg =
            state.progress[subject] || { mastery: 0, xp: 0, lastStudied: 0 };
          const newMastery = Math.min(100, subjectProg.mastery + amount * 0.1);

          const next: AppState = {
            ...state,
            totalXp: state.totalXp + amount,
            lastStudyDate: today,
            currentStreak: newStreak,
            longestStreak: Math.max(state.longestStreak, newStreak),
            progress: {
              ...state.progress,
              [subject]: {
                mastery: newMastery,
                xp: subjectProg.xp + amount,
                lastStudied: Date.now(),
              },
            },
          };

          return { ...next, badges: checkBadges(next) };
        }),

      addSession: (session) =>
        set((state) => ({ sessions: [session, ...state.sessions].slice(0, 200) })),

      resetProgress: () =>
        set(() => ({
          profile: defaultProfile,
          progress: {},
          sessions: [],
          badges: [],
          totalXp: 0,
          currentStreak: 0,
          longestStreak: 0,
          lastStudyDate: '',
          chatHistory: {},
          quizCorrect: 0,
          languagesUsed: [],
          flashcardDecks: [],
          studyPlan: null,
          focusSessions: [],
          pastPaperAttempts: [],
          sleepReviewEnabled: false,
        })),

      addChatMessage: (subject, message) =>
        set((state) => {
          const history = state.chatHistory[subject] || [];
          return {
            chatHistory: { ...state.chatHistory, [subject]: [...history, message] },
          };
        }),

      clearChatHistory: (subject) =>
        set((state) => ({
          chatHistory: { ...state.chatHistory, [subject]: [] },
        })),

      recordQuizCorrect: () =>
        set((state) => {
          const next = { ...state, quizCorrect: state.quizCorrect + 1 };
          return { ...next, badges: checkBadges(next) };
        }),

      trackLanguage: (lang) =>
        set((state) => {
          if (state.languagesUsed.includes(lang)) return state;
          const next = { ...state, languagesUsed: [...state.languagesUsed, lang] };
          return { ...next, badges: checkBadges(next) };
        }),

      saveFlashcardDeck: (deck) =>
        set((state) => {
          const next = {
            ...state,
            flashcardDecks: [deck, ...state.flashcardDecks].slice(0, 50),
          };
          return { ...next, badges: checkBadges(next) };
        }),

      deleteFlashcardDeck: (id) =>
        set((state) => ({
          flashcardDecks: state.flashcardDecks.filter((d) => d.id !== id),
        })),

      reviewFlashcard: (deckId, cardId, quality) =>
        set((state) => {
          const decks = state.flashcardDecks.map((deck) => {
            if (deck.id !== deckId) return deck;
            const cards = deck.cards.map((card) => {
              if (card.id !== cardId) return card;
              // SM-2-lite: quality 0 = forgot, 1 = hard, 2 = good, 3 = easy
              let { ease, interval, reps } = card;
              if (quality === 0) {
                interval = 1;
                reps = 0;
                ease = Math.max(1.3, ease - 0.2);
              } else {
                reps += 1;
                ease = Math.max(1.3, ease + (quality === 3 ? 0.15 : quality === 1 ? -0.05 : 0));
                if (reps === 1) interval = 1;
                else if (reps === 2) interval = 3;
                else interval = Math.round(interval * ease);
              }
              const due = Date.now() + interval * 24 * 60 * 60 * 1000;
              return { ...card, ease, interval, reps, due };
            });
            return { ...deck, cards };
          });
          return { flashcardDecks: decks };
        }),

      setStudyPlan: (plan) => set(() => ({ studyPlan: plan })),

      togglePlannerBlock: (dayIndex, blockIndex) =>
        set((state) => {
          if (!state.studyPlan) return state;
          const days = state.studyPlan.days.map((d, di) => {
            if (di !== dayIndex) return d;
            const blocks = d.blocks.map((b, bi) =>
              bi === blockIndex ? { ...b, done: !b.done } : b,
            );
            return { ...d, blocks };
          });
          return { studyPlan: { ...state.studyPlan, days } };
        }),

      addFocusSession: (s) =>
        set((state) => {
          const next = {
            ...state,
            focusSessions: [s, ...state.focusSessions].slice(0, 200),
          };
          return { ...next, badges: checkBadges(next) };
        }),

      setSleepReview: (on) => set(() => ({ sleepReviewEnabled: on })),

      addPastPaperAttempt: (a) =>
        set((state) => {
          const next = {
            ...state,
            pastPaperAttempts: [a, ...state.pastPaperAttempts].slice(0, 100),
          };
          return { ...next, badges: checkBadges(next) };
        }),

      updatePastPaperAttempt: (id, patch) =>
        set((state) => {
          const next = {
            ...state,
            pastPaperAttempts: state.pastPaperAttempts.map((a) =>
              a.id === id ? { ...a, ...patch } : a,
            ),
          };
          return { ...next, badges: checkBadges(next) };
        }),
    }),
    {
      name: 'thinkr-storage',
    },
  ),
);

export const useProfile = () => useStore((state) => state.profile);
export const useProgress = () => useStore((state) => state.progress);
export const useSessions = () => useStore((state) => state.sessions);
