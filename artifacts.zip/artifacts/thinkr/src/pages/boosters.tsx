import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, useProfile } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Brain,
  Play,
  Pause,
  RotateCcw,
  Moon,
  Sunrise,
  Wand2,
  Coffee,
  Timer,
} from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import { motion } from "framer-motion";

const FOCUS_PRESETS = [15, 25, 45, 50];
const BREAK_MINUTES = 5;

export default function Boosters() {
  const profile = useProfile();
  const focusSessions = useStore((s) => s.focusSessions);
  const sleepReviewEnabled = useStore((s) => s.sleepReviewEnabled);
  const setSleepReview = useStore((s) => s.setSleepReview);
  const addFocusSession = useStore((s) => s.addFocusSession);
  const addXp = useStore((s) => s.addXp);
  const progress = useStore((s) => s.progress);

  const [duration, setDuration] = useState<number>(25);
  const [secondsLeft, setSecondsLeft] = useState<number>(25 * 60);
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState<"focus" | "break">("focus");
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!running) return;
    intervalRef.current = setInterval(() => {
      setSecondsLeft((s) => Math.max(0, s - 1));
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (secondsLeft !== 0) return;
    if (!running) return;
    if (phase === "focus") {
      const subject =
        Object.entries(progress).sort((a, b) => b[1].lastStudied - a[1].lastStudied)[0]?.[0] ??
        "Study";
      addFocusSession({
        id: uuidv4(),
        timestamp: Date.now(),
        durationMinutes: duration,
        subject,
      });
      addXp(Math.round(duration / 5) * 5, subject);
      setPhase("break");
      setSecondsLeft(BREAK_MINUTES * 60);
    } else {
      setPhase("focus");
      setSecondsLeft(duration * 60);
      setRunning(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft]);

  function pickDuration(m: number) {
    setDuration(m);
    setSecondsLeft(m * 60);
    setPhase("focus");
    setRunning(false);
  }

  function resetTimer() {
    setRunning(false);
    setPhase("focus");
    setSecondsLeft(duration * 60);
  }

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const totalSeconds = (phase === "focus" ? duration : BREAK_MINUTES) * 60;
  const pct = ((totalSeconds - secondsLeft) / totalSeconds) * 100;

  const recentSubject = useMemo(() => {
    return (
      Object.entries(progress).sort((a, b) => b[1].lastStudied - a[1].lastStudied)[0]?.[0] ??
      null
    );
  }, [progress]);

  const totalFocusMinutes = useMemo(
    () => focusSessions.reduce((sum, f) => sum + f.durationMinutes, 0),
    [focusSessions],
  );

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <Brain className="h-5 w-5" />
          <span className="text-sm font-medium uppercase tracking-wider">
            Cognitive boosters
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold">Train your study brain</h1>
        <p className="text-muted-foreground max-w-2xl">
          Focus blocks, sleep-based memory review, and a quick brain warm-up. Small
          things, done daily, are how grades actually move.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Timer className="h-5 w-5 text-primary" />
              Focus timer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap gap-2">
              {FOCUS_PRESETS.map((m) => (
                <button
                  key={m}
                  onClick={() => pickDuration(m)}
                  className={`px-3 py-1.5 rounded-full border text-sm transition-colors ${
                    duration === m
                      ? "bg-primary text-primary-foreground border-primary"
                      : "hover:bg-muted"
                  }`}
                >
                  {m} min
                </button>
              ))}
            </div>

            <div className="relative flex items-center justify-center py-6">
              <svg className="absolute" width="240" height="240" viewBox="0 0 240 240">
                <circle
                  cx="120"
                  cy="120"
                  r="110"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="none"
                  className="text-muted/40"
                />
                <motion.circle
                  cx="120"
                  cy="120"
                  r="110"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="none"
                  strokeLinecap="round"
                  className="text-primary"
                  strokeDasharray={2 * Math.PI * 110}
                  strokeDashoffset={(2 * Math.PI * 110) * (1 - pct / 100)}
                  transform="rotate(-90 120 120)"
                  initial={false}
                  animate={{ strokeDashoffset: (2 * Math.PI * 110) * (1 - pct / 100) }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </svg>
              <div className="text-center">
                <div className="text-5xl md:text-6xl font-bold tabular-nums">
                  {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
                </div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground mt-2 flex items-center justify-center gap-1">
                  {phase === "focus" ? (
                    <>
                      <Brain className="h-3 w-3" /> Deep focus
                    </>
                  ) : (
                    <>
                      <Coffee className="h-3 w-3" /> Short break
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex justify-center gap-3">
              <Button onClick={() => setRunning((v) => !v)} size="lg">
                {running ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    {secondsLeft === duration * 60 ? "Start" : "Resume"}
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={resetTimer} size="lg">
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-2xl font-bold">{focusSessions.length}</p>
                <p className="text-xs text-muted-foreground">Focus blocks done</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-2xl font-bold">{totalFocusMinutes}</p>
                <p className="text-xs text-muted-foreground">Minutes focused</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Moon className="h-5 w-5 text-primary" />
              Sleep-based review
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Memory consolidates while you sleep. Turn this on to get a 5-minute
              review nudge before bed and a quick recall prompt in the morning.
            </p>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <Label htmlFor="sleep-review" className="text-sm font-medium">
                Sleep-hook reminders
              </Label>
              <Switch
                id="sleep-review"
                checked={sleepReviewEnabled}
                onCheckedChange={setSleepReview}
              />
            </div>
            {sleepReviewEnabled && recentSubject && (
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  <Moon className="h-4 w-4 text-primary" />
                  <div>
                    <p className="font-medium">Tonight</p>
                    <p className="text-xs text-muted-foreground">
                      Skim {recentSubject} flashcards for 5 minutes before sleep.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border">
                  <Sunrise className="h-4 w-4 text-amber-500" />
                  <div>
                    <p className="font-medium">Tomorrow morning</p>
                    <p className="text-xs text-muted-foreground">
                      Try to recall what you studied without looking. Then check.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-primary" />
              Brain warm-up
            </CardTitle>
          </CardHeader>
          <CardContent>
            <BrainWarmup studentName={profile.name} onWin={() => addXp(5, "Warm-up")} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function BrainWarmup({
  studentName,
  onWin,
}: {
  studentName: string;
  onWin: () => void;
}) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [showing, setShowing] = useState<number | null>(null);
  const [phase, setPhase] = useState<"idle" | "show" | "input" | "win" | "lose">(
    "idle",
  );
  const [step, setStep] = useState(0);
  const [round, setRound] = useState(0);

  function start() {
    const next = Array.from({ length: 3 + round }, () =>
      Math.floor(Math.random() * 4),
    );
    setSequence(next);
    setStep(0);
    setPhase("show");
    next.forEach((n, i) => {
      setTimeout(() => setShowing(n), 600 * (i + 1));
      setTimeout(() => setShowing(null), 600 * (i + 1) + 350);
    });
    setTimeout(() => {
      setPhase("input");
    }, 600 * next.length + 500);
  }

  function press(n: number) {
    if (phase !== "input") return;
    if (sequence[step] !== n) {
      setPhase("lose");
      return;
    }
    if (step + 1 === sequence.length) {
      setPhase("win");
      onWin();
      setRound((r) => r + 1);
      return;
    }
    setStep((s) => s + 1);
  }

  const colors = [
    "bg-emerald-500",
    "bg-rose-500",
    "bg-amber-500",
    "bg-sky-500",
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 items-center">
      <div className="space-y-3">
        <p className="text-sm">
          Watch the sequence, then tap it back. Each round adds one more.
        </p>
        <p className="text-sm text-muted-foreground">
          Length: <strong>{3 + round}</strong> · Round: <strong>{round + 1}</strong>
        </p>
        <div className="flex gap-2">
          <Button onClick={start} disabled={phase === "show" || phase === "input"}>
            <Play className="h-4 w-4 mr-2" />
            {phase === "idle" || phase === "lose" ? "Start" : "Next round"}
          </Button>
          {phase === "lose" && (
            <Button
              variant="outline"
              onClick={() => {
                setRound(0);
                setPhase("idle");
              }}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          )}
        </div>
        <p className="text-sm">
          {phase === "show" && "Watch carefully..."}
          {phase === "input" && "Now repeat it."}
          {phase === "win" && `Nice one${studentName ? `, ${studentName}` : ""}!`}
          {phase === "lose" && "Close! Reset and try again."}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-3 max-w-sm w-full mx-auto">
        {[0, 1, 2, 3].map((n) => (
          <motion.button
            key={n}
            onClick={() => press(n)}
            animate={
              showing === n
                ? { scale: 1.05, opacity: 1 }
                : { scale: 1, opacity: showing === null ? 1 : 0.55 }
            }
            transition={{ duration: 0.2 }}
            className={`${colors[n]} h-24 rounded-xl shadow-md`}
          />
        ))}
      </div>
    </div>
  );
}
