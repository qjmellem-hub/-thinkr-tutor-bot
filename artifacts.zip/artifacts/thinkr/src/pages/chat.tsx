import { useState, useRef, useEffect } from "react";
import { useStore, useProfile, ChatMessage } from "@/lib/store";
import { SUBJECTS, EDUCATION_CATEGORIES, TEACHING_STYLES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Send, Bot, User, BrainCircuit, RefreshCw, AlertCircle, Sparkles, Library, BookMarked, Loader2, Sigma, Lightbulb, BookOpen, Paperclip, X, ExternalLink, GraduationCap, FileText, ShieldCheck, Leaf } from "lucide-react";
import { compressImage } from "@/lib/image-compress";
import ReactMarkdown from "react-markdown";
import { v4 as uuidv4 } from "uuid";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

const API_BASE = `${import.meta.env.BASE_URL}api`;

interface Foundation {
  concept: string;
  fromLevel: string;
  type: "formula" | "concept" | "example" | "rule";
  title: string;
  explanation: string;
  example: string;
  capsRef: string;
  nqfRef: string;
  sourceUrl: string;
  verifiedSource: string;
}

interface FoundationsResponse {
  concepts: string[];
  foundations: Foundation[];
  curriculum?: string;
  sources?: { name: string; url: string }[];
}

export default function Chat() {
  const profile = useProfile();
  const store = useStore();
  const [location, setLocation] = useLocation();

  const queryParams = new URLSearchParams(window.location.search);
  const initialSubject = queryParams.get("subject") || "";

  const [subject, setSubject] = useState<string>(initialSubject);
  const [topic, setTopic] = useState("");
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [error, setError] = useState("");
  
  const [quizData, setQuizData] = useState<any>(null);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [quizLoading, setQuizLoading] = useState(false);

  const [foundationsOpen, setFoundationsOpen] = useState(false);
  const [foundationsLoading, setFoundationsLoading] = useState(false);
  const [foundationsData, setFoundationsData] = useState<FoundationsResponse | null>(null);
  const [foundationsForQuestion, setFoundationsForQuestion] = useState<string>("");

  const [pendingImages, setPendingImages] = useState<string[]>([]);
  const [imageError, setImageError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  const dataSaver = profile.dataSaver !== false;
  const MAX_IMAGES = dataSaver ? 1 : 4;
  const MAX_IMAGE_BYTES = dataSaver ? 1 * 1024 * 1024 : 4 * 1024 * 1024;

  const handlePickImages = () => {
    setImageError("");
    fileInputRef.current?.click();
  };

  const handleFilesSelected = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setImageError("");
    const slotsLeft = MAX_IMAGES - pendingImages.length;
    if (slotsLeft <= 0) {
      setImageError(`You can attach up to ${MAX_IMAGES} images per message.`);
      return;
    }
    const picks = Array.from(files).slice(0, slotsLeft);
    const next: string[] = [];
    for (const file of picks) {
      if (!file.type.startsWith("image/")) {
        setImageError("Only image files are allowed.");
        continue;
      }
      if (file.size > MAX_IMAGE_BYTES) {
        setImageError("Each image must be under 4MB.");
        continue;
      }
      try {
        const dataUrl = dataSaver
          ? await compressImage(file, { maxDim: 1024, quality: 0.6 })
          : await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve(String(reader.result));
              reader.onerror = () => reject(new Error("read failed"));
              reader.readAsDataURL(file);
            });
        next.push(dataUrl);
      } catch {
        setImageError("Couldn't read one of the images.");
      }
    }
    if (next.length > 0) setPendingImages((cur) => [...cur, ...next]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removePendingImage = (idx: number) => {
    setPendingImages((cur) => cur.filter((_, i) => i !== idx));
  };

  // Auto scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [store.chatHistory, streamingMessage, quizData]);

  // If subject is selected but it's not a valid subject for the user's category, reset it
  const validSubjects = profile.category === 'Tertiary' 
    ? [] // Custom input
    : SUBJECTS[profile.category as keyof typeof SUBJECTS] || [];

  const chatHistory = subject ? (store.chatHistory[subject] || []) : [];

  const handleSend = async () => {
    if ((!input.trim() && pendingImages.length === 0) || !subject) return;

    const imagesToSend = pendingImages;
    const messageText =
      input.trim() ||
      (imagesToSend.length > 0
        ? "Please look at the attached image and help me understand it."
        : "");

    const displayContent =
      imagesToSend.length > 0
        ? `${messageText}\n\n_(${imagesToSend.length} image${imagesToSend.length > 1 ? "s" : ""} attached)_`
        : messageText;

    const userMessage: ChatMessage = {
      id: uuidv4(),
      role: 'user',
      content: displayContent,
      timestamp: Date.now()
    };

    store.addChatMessage(subject, userMessage);
    setInput("");
    setPendingImages([]);
    setImageError("");
    setIsTyping(true);
    setError("");
    setStreamingMessage("");

    // Award XP for asking a question (just a tiny bit to encourage activity)
    store.addXp(2, subject);

    try {
      const response = await fetch(`${API_BASE}/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          history: chatHistory.map(m => ({ role: m.role, content: m.content })),
          subject,
          level: profile.level,
          teachingStyle: profile.teachingStyle,
          language: profile.language,
          studentName: profile.name,
          apiKey: profile.apiKey || undefined,
          images: imagesToSend,
          dataSaver,
        })
      });

      if (!response.ok) throw new Error("Failed to connect to the study buddy.");

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullResponse = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n').filter(line => line.trim().startsWith('data: '));
          
          for (const line of lines) {
            const dataStr = line.replace(/^data: /, '');
            try {
              const data = JSON.parse(dataStr);
              if (data.error) {
                setError(data.error);
                break;
              }
              if (data.done) {
                // Done streaming
              } else if (data.content) {
                fullResponse += data.content;
                setStreamingMessage(fullResponse);
              }
            } catch (e) {
              console.error("Error parsing stream data", e);
            }
          }
        }
      }

      // Add final message
      if (fullResponse) {
        const assistantMessage: ChatMessage = {
          id: uuidv4(),
          role: 'assistant',
          content: fullResponse,
          timestamp: Date.now()
        };
        store.addChatMessage(subject, assistantMessage);
        // Award XP for getting a response
        store.addXp(10, subject);
        
        // Add session if it's the first interaction today for this subject
        store.addSession({
          id: uuidv4(),
          timestamp: Date.now(),
          subject,
          topic: topic || "General Q&A",
          durationMinutes: 5 // rough estimate per interaction
        });
      }

    } catch (err: any) {
      setError(err.message || "Something went wrong. Let's try that again.");
    } finally {
      setIsTyping(false);
      setStreamingMessage("");
    }
  };

  const handleQuiz = async () => {
    if (!subject) return;
    setQuizLoading(true);
    setError("");
    setQuizData(null);
    setQuizAnswer(null);

    try {
      const response = await fetch(`${API_BASE}/chat/quiz`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          level: profile.level,
          topic: topic || "General",
          language: profile.language
        })
      });

      if (!response.ok) throw new Error("Failed to generate quiz.");
      const data = await response.json();
      setQuizData(data);
    } catch (err: any) {
      setError("Couldn't generate a quiz right now. Try again later.");
    } finally {
      setQuizLoading(false);
    }
  };

  const handleFoundations = async (question: string) => {
    if (!subject || !question.trim()) return;
    setFoundationsOpen(true);
    setFoundationsForQuestion(question);
    setFoundationsData(null);
    setFoundationsLoading(true);

    const cacheKey = `thinkr-foundations:${subject}|${profile.level}|${profile.language}|${question.toLowerCase().trim()}`;
    if (dataSaver) {
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
          setFoundationsData(JSON.parse(cached) as FoundationsResponse);
          setFoundationsLoading(false);
          return;
        }
      } catch {
        // ignore
      }
    }

    try {
      const response = await fetch(`${API_BASE}/chat/foundations`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          subject,
          level: profile.level,
          language: profile.language,
          dataSaver,
        }),
      });
      if (!response.ok) throw new Error("Failed");
      const data = (await response.json()) as FoundationsResponse;
      setFoundationsData(data);
      store.addXp(5, subject);
      if (dataSaver) {
        try {
          localStorage.setItem(cacheKey, JSON.stringify(data));
          const idxKey = "thinkr-foundations:index";
          const idx = JSON.parse(localStorage.getItem(idxKey) ?? "[]") as string[];
          const nextIdx = [cacheKey, ...idx.filter((k) => k !== cacheKey)].slice(0, 30);
          localStorage.setItem(idxKey, JSON.stringify(nextIdx));
          // evict overflow
          for (const k of idx) {
            if (!nextIdx.includes(k)) localStorage.removeItem(k);
          }
        } catch {
          // localStorage full or disabled — silently skip
        }
      }
    } catch {
      setFoundationsData({ concepts: [], foundations: [] });
    } finally {
      setFoundationsLoading(false);
    }
  };

  const handleQuizAnswer = (idx: number) => {
    if (quizAnswer !== null) return;
    setQuizAnswer(idx);
    
    if (idx === quizData.answerIndex) {
      store.addXp(20, subject);
      // Trigger a mini celebration or just standard update
    }
  };

  if (!profile.hasOnboarded) {
    setLocation("/");
    return null;
  }

  return (
    <div className="flex flex-col h-[calc(100dvh-5rem)] md:h-[calc(100dvh-4rem)] max-w-4xl mx-auto border bg-card rounded-2xl shadow-sm overflow-hidden animate-in fade-in">
      {/* Header */}
      <div className="p-4 border-b bg-muted/30 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-lg text-primary">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-semibold leading-tight">Study Session</h2>
            <div className="text-xs text-muted-foreground flex gap-2">
              <span>{profile.level}</span> • <span>{profile.teachingStyle} Style</span>
              {dataSaver && (
                <>
                  {" • "}
                  <span
                    className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium"
                    title="Data Saver mode is on. Replies are short, images compressed, and answers cached."
                  >
                    <Leaf className="w-3 h-3" /> Data Saver
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex w-full sm:w-auto gap-2">
          {profile.category === 'Tertiary' ? (
            <Input 
              placeholder="e.g. Microeconomics 101" 
              value={subject} 
              onChange={(e) => setSubject(e.target.value)}
              className="w-full sm:w-[200px]"
            />
          ) : (
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {validSubjects.map(sub => (
                  <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6" ref={scrollRef}>
        {!subject ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
            <Bot className="w-16 h-16 text-muted-foreground" />
            <div className="text-lg font-medium">Select a subject to start studying!</div>
          </div>
        ) : chatHistory.length === 0 && !isTyping ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 max-w-md mx-auto">
            <div className="bg-primary/10 p-4 rounded-full">
              <Sparkles className="w-10 h-10 text-primary" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-medium">Ready for {subject}?</h3>
              <p className="text-muted-foreground">
                Ask me a question, paste in a homework problem, or ask me to explain a concept from {profile.level}.
              </p>
            </div>
          </div>
        ) : (
          <>
            {chatHistory.map((msg, i) => {
              // For an assistant message, find the user question that prompted it (the immediately preceding user message)
              const priorUserQuestion = msg.role === "assistant"
                ? [...chatHistory.slice(0, i)].reverse().find((m) => m.role === "user")?.content ?? ""
                : "";
              return (
                <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 mt-1">
                      <Bot className="w-5 h-5" />
                    </div>
                  )}

                  <div className={`max-w-[85%] flex flex-col gap-2 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`rounded-2xl px-5 py-3 w-full ${
                      msg.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-tr-sm'
                        : 'bg-muted rounded-tl-sm prose prose-sm dark:prose-invert prose-p:leading-relaxed prose-pre:bg-black/5 dark:prose-pre:bg-white/5 prose-pre:text-foreground'
                    }`}>
                      {msg.role === 'user' ? (
                        <div className="whitespace-pre-wrap">{msg.content}</div>
                      ) : (
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      )}
                    </div>
                    {msg.role === 'assistant' && priorUserQuestion && (
                      <button
                        onClick={() => handleFoundations(priorUserQuestion)}
                        className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-medium"
                        title="See prerequisite concepts from earlier grades"
                      >
                        <Library className="w-3.5 h-3.5" />
                        View foundations
                      </button>
                    )}
                  </div>

                  {msg.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center flex-shrink-0 mt-1">
                      <User className="w-5 h-5" />
                    </div>
                  )}
                </div>
              );
            })}

            {isTyping && streamingMessage && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="w-5 h-5" />
                </div>
                <div className="max-w-[85%] rounded-2xl rounded-tl-sm px-5 py-3 bg-muted prose prose-sm dark:prose-invert">
                  <ReactMarkdown>{streamingMessage}</ReactMarkdown>
                  <span className="inline-block w-1.5 h-4 ml-1 bg-primary animate-pulse align-middle" />
                </div>
              </div>
            )}

            {isTyping && !streamingMessage && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="w-5 h-5" />
                </div>
                <div className="bg-muted rounded-2xl rounded-tl-sm px-5 py-4 flex gap-1 items-center h-10">
                  <div className="w-1.5 h-1.5 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-1.5 h-1.5 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-1.5 h-1.5 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            )}

            {error && (
              <div className="flex gap-2 items-center text-destructive bg-destructive/10 p-3 rounded-lg mx-auto w-fit text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            {/* Inline Quiz */}
            {quizLoading && (
              <div className="flex justify-center py-4">
                <div className="animate-spin text-primary"><RefreshCw className="w-6 h-6" /></div>
              </div>
            )}

            {quizData && (
              <Card className="my-4 border-primary/20 shadow-md">
                <CardHeader className="bg-primary/5 pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" /> Pop Quiz!
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <p className="font-medium text-lg">{quizData.question}</p>
                  <div className="grid gap-2">
                    {quizData.choices.map((choice: string, idx: number) => {
                      const isSelected = quizAnswer === idx;
                      const isCorrect = idx === quizData.answerIndex;
                      const showResult = quizAnswer !== null;
                      
                      let btnVariant: "outline" | "default" | "destructive" | "secondary" = "outline";
                      if (showResult) {
                        if (isCorrect) btnVariant = "default"; // green-ish if we map primary well
                        else if (isSelected) btnVariant = "destructive";
                        else btnVariant = "secondary";
                      } else if (isSelected) {
                        btnVariant = "secondary";
                      }

                      return (
                        <Button 
                          key={idx} 
                          variant={btnVariant}
                          className={`justify-start h-auto py-3 px-4 text-left whitespace-normal ${
                            showResult && isCorrect ? 'bg-green-600 text-white hover:bg-green-700' : ''
                          }`}
                          onClick={() => handleQuizAnswer(idx)}
                          disabled={showResult}
                        >
                          {choice}
                        </Button>
                      );
                    })}
                  </div>
                  {quizAnswer !== null && (
                    <div className={`p-4 rounded-lg mt-4 ${
                      quizAnswer === quizData.answerIndex ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' : 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
                    }`}>
                      <p className="font-medium mb-1">
                        {quizAnswer === quizData.answerIndex ? 'Nailed it! +20 XP' : 'Not quite!'}
                      </p>
                      <p className="text-sm">{quizData.explanation}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>

      {/* Foundations modal */}
      <Dialog open={foundationsOpen} onOpenChange={setFoundationsOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Library className="w-5 h-5 text-primary" />
              Foundations
            </DialogTitle>
            <DialogDescription>
              Building blocks from earlier grades you need to fully understand this question.
            </DialogDescription>
          </DialogHeader>

          {foundationsForQuestion && (
            <div className="text-xs text-muted-foreground italic border-l-2 border-primary/40 pl-3 py-1">
              "{foundationsForQuestion.slice(0, 180)}{foundationsForQuestion.length > 180 ? "..." : ""}"
            </div>
          )}

          {foundationsLoading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-3 text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-sm">Mapping prerequisite concepts...</p>
            </div>
          ) : !foundationsData || foundationsData.foundations.length === 0 ? (
            <div className="text-center py-12 text-sm text-muted-foreground">
              No foundations found for this question. Try asking the tutor a more specific question first.
            </div>
          ) : (
            <div className="space-y-4">
              {foundationsData.concepts.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground self-center">Core concepts:</span>
                  {foundationsData.concepts.map((c) => (
                    <Badge key={c} variant="secondary">{c}</Badge>
                  ))}
                </div>
              )}
              <Separator />
              <div className="space-y-3">
                {foundationsData.foundations.map((f, i) => {
                  const Icon =
                    f.type === "formula"
                      ? Sigma
                      : f.type === "example"
                      ? Lightbulb
                      : f.type === "rule"
                      ? BookMarked
                      : BookOpen;
                  const hasReferences = f.capsRef || f.nqfRef || f.sourceUrl || f.verifiedSource;
                  const verifiedClass =
                    f.verifiedSource === "DBE Official"
                      ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900"
                      : f.verifiedSource === "WCED ePortal"
                      ? "bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-900"
                      : f.verifiedSource === "SAQA"
                      ? "bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-950/40 dark:text-violet-300 dark:border-violet-900"
                      : "bg-muted text-muted-foreground border-border";
                  return (
                    <div
                      key={i}
                      className="border rounded-xl p-4 hover:border-primary/40 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="bg-primary/10 text-primary p-2 rounded-lg flex-shrink-0">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <h4 className="font-semibold leading-tight">{f.title}</h4>
                            <div className="flex items-center gap-1.5">
                              {f.fromLevel && (
                                <Badge variant="outline" className="text-[10px]">
                                  {f.fromLevel}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {f.explanation}
                          </p>
                          {f.example && (
                            <div className="text-xs bg-muted/60 rounded-lg p-2.5 mt-2">
                              <span className="font-medium text-foreground">Example: </span>
                              <span className="text-muted-foreground">{f.example}</span>
                            </div>
                          )}
                          {hasReferences && (
                            <div className="pt-2 mt-2 border-t border-dashed space-y-1.5 text-xs">
                              {f.verifiedSource && (
                                <div>
                                  <span
                                    className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border text-[10px] font-medium ${verifiedClass}`}
                                  >
                                    <ShieldCheck className="w-3 h-3" />
                                    {f.verifiedSource === "Format match"
                                      ? "CAPS format match"
                                      : `Verified via ${f.verifiedSource}`}
                                  </span>
                                </div>
                              )}
                              {f.capsRef && (
                                <div className="flex items-start gap-1.5 text-muted-foreground">
                                  <FileText className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-primary/70" />
                                  <span>
                                    <span className="font-medium text-foreground">CAPS:</span>{" "}
                                    {f.capsRef}
                                  </span>
                                </div>
                              )}
                              {f.nqfRef && (
                                <div className="flex items-start gap-1.5 text-muted-foreground">
                                  <GraduationCap className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-primary/70" />
                                  <span>
                                    <span className="font-medium text-foreground">NQF:</span>{" "}
                                    {f.nqfRef}
                                  </span>
                                </div>
                              )}
                              {f.sourceUrl && (
                                <a
                                  href={f.sourceUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 text-primary hover:underline"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                  View official document
                                </a>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <p className="text-[10px] text-center text-muted-foreground pt-2">
                  Citations are AI-generated guides to the CAPS curriculum and may not be exact. Always cross-check with your official textbook.
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Input Area */}
      <div className="border-t bg-muted/30">
        {/* Image previews */}
        {(pendingImages.length > 0 || imageError) && (
          <div className="px-3 pt-3 space-y-2">
            {pendingImages.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {pendingImages.map((url, idx) => (
                  <div
                    key={idx}
                    className="relative w-16 h-16 rounded-lg overflow-hidden border bg-background group"
                  >
                    <img
                      src={url}
                      alt={`attachment ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removePendingImage(idx)}
                      className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80"
                      aria-label="Remove image"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            {imageError && (
              <div className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {imageError}
              </div>
            )}
          </div>
        )}

        <div className="p-3 flex gap-2 items-end">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => handleFilesSelected(e.target.files)}
          />
          <Button
            variant="outline"
            size="icon"
            className="h-12 w-12 flex-shrink-0 rounded-xl"
            onClick={handlePickImages}
            disabled={!subject || isTyping || pendingImages.length >= MAX_IMAGES}
            title="Attach an image"
          >
            <Paperclip className="w-5 h-5" />
          </Button>
          {subject && chatHistory.length > 0 && !isTyping && (
            <Button
              variant="outline"
              size="icon"
              className="h-12 w-12 flex-shrink-0 rounded-xl"
              onClick={handleQuiz}
              title="Quiz me on this"
            >
              <Sparkles className="w-5 h-5 text-primary" />
            </Button>
          )}
          <Input
            className="h-12 rounded-xl text-base"
            placeholder={subject ? "Ask your study buddy anything..." : "Select a subject first..."}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            disabled={!subject || isTyping}
          />
          <Button
            className="h-12 px-6 rounded-xl shrink-0"
            onClick={handleSend}
            disabled={!subject || (!input.trim() && pendingImages.length === 0) || isTyping}
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
