import { useStore, useProfile } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, Flame, Clock, BookOpen, Calendar, Trophy, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const store = useStore();
  const profile = useProfile();

  const totalMinutes = store.sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const subjectsTouched = Object.keys(store.progress).length;
  
  // Get sessions from the last 7 days
  const oneWeekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const sessionsThisWeek = store.sessions.filter(s => s.timestamp > oneWeekAgo).length;

  return (
    <div className="space-y-8 animate-in fade-in">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Your study journey at a glance.</p>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-6 space-y-2">
            <Flame className="w-6 h-6 text-orange-500" />
            <div className="space-y-1">
              <div className="text-2xl font-bold">{store.currentStreak} Days</div>
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Current Streak</div>
            </div>
            <div className="text-xs pt-2 border-t border-primary/10 text-muted-foreground">
              Best: {store.longestStreak} days
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <div className="space-y-1">
              <div className="text-2xl font-bold">{store.totalXp}</div>
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Total XP</div>
            </div>
            <div className="text-xs pt-2 border-t text-muted-foreground">
              Keep it up!
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-2">
            <Clock className="w-6 h-6 text-blue-500" />
            <div className="space-y-1">
              <div className="text-2xl font-bold">
                {totalMinutes < 60 ? `${totalMinutes}m` : `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m`}
              </div>
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Study Time</div>
            </div>
            <div className="text-xs pt-2 border-t text-muted-foreground">
              {sessionsThisWeek} sessions this week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-2">
            <Trophy className="w-6 h-6 text-yellow-500" />
            <div className="space-y-1">
              <div className="text-2xl font-bold">{store.badges.length}</div>
              <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Badges Earned</div>
            </div>
            <div className="text-xs pt-2 border-t text-muted-foreground">
              Across {subjectsTouched} subjects
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-semibold">Recent Sessions</h3>
          <Link href="/progress" className="text-sm font-medium text-primary hover:underline flex items-center">
            View full progress <ArrowRight className="w-4 h-4 ml-1" />
          </Link>
        </div>

        {store.sessions.length === 0 ? (
          <Card className="p-12 text-center border-dashed">
            <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium">No sessions yet</h3>
            <p className="text-muted-foreground mt-1 mb-4">Your recent study history will appear here.</p>
            <Link href="/chat">
              <span className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                Start Studying
              </span>
            </Link>
          </Card>
        ) : (
          <div className="grid gap-3">
            {store.sessions.slice(0, 5).map((session, i) => (
              <Card key={session.id} className="overflow-hidden hover:border-primary/30 transition-colors">
                <div className="flex p-4 items-center gap-4">
                  <div className="bg-muted p-3 rounded-lg flex-shrink-0">
                    <BookOpen className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-base truncate">{session.subject}</h4>
                    <p className="text-sm text-muted-foreground truncate">{session.topic}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm font-medium">{new Date(session.timestamp).toLocaleDateString()}</div>
                    <div className="text-xs text-muted-foreground">{session.durationMinutes} mins</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
