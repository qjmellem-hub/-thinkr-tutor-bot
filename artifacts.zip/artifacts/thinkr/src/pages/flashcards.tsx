import { useMemo, useState } from "react";
import {
  useStore,
  useProfile,
  type Flashcard,
  type FlashcardDeck,
} from "@/lib/store";
import { API_BASE, SUBJECTS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Layers,
  Loader2,
  Sparkles,
  AlertCircle,
  ChevronLeft,
  Trash2,
  RotateCw,
} from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import { motion, AnimatePresence } from "framer-motion";

const COUNT_OPTIONS = [5, 8, 10, 15, 20];

export default function Flashcards() {
  const profile = useProfile();
  const decks = useStore((s) => s.flashcardDecks);
  const saveFlashcardDeck = useStore((s) => s.saveFlashcardDeck);
  const deleteFlashcardDeck = useStore((s) => s.deleteFlashcardDeck);
  const reviewFlashcard = useStore((s) => s.reviewFlashcard);
  const addXp = useStore((s) => s.addXp);

  const subjectsForLevel = useMemo<string[]>(() => {
    if (profile.category === "Tertiary") return ["My module"];
    return (
      SUBJECTS[profile.category as "Foundation/Intermediate" | "Senior/FET"] ?? [
        "Mathematics",
      ]
    );
  }, [profile.category]);

  const [subject, setSubject] = useState<string>(subjectsForLevel[0] ?? "Mathematics");
  const [topic, setTopic] = useState("");
  const [count, setCount] = useState<number>(8);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeDeckId, setActiveDeckId] = useState<string | null>(null);

  const activeDeck = useMemo(
    () => decks.find((d) => d.id === activeDeckId) ?? null,
    [activeDeckId, decks],
  );

  async function generate() {
    if (!topic.trim()) {
      setError("Tell Thinkr what topic to make cards on.");
      return;
    }
    setError(null);
    setGenerating(true);
    try {
      const res = await fetch(`${API_BASE}/chat/flashcards`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject,
          level: profile.level,
          topic: topic.trim(),
          language: profile.language,
          count,
        }),
      });
      if (!res.ok) throw new Error("Could not generate flashcards");
      const data = await res.json();
      const cards: Flashcard[] = (data.cards ?? []).map((c: { front: string; back: string; hint: string }) => ({
        id: uuidv4(),
        front: c.front,
        back: c.back,
        hint: c.hint,
        ease: 2.5,
        interval: 0,
        due: Date.now(),
        reps: 0,
      }));
      if (cards.length === 0) throw new Error("No cards came back");
      const deck: FlashcardDeck = {
        id: uuidv4(),
        subject,
        topic: topic.trim(),
        language: profile.language,
        level: profile.level,
        createdAt: Date.now(),
        cards,
      };
      saveFlashcardDeck(deck);
      addXp(15, subject);
      setActiveDeckId(deck.id);
      setTopic("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setGenerating(false);
    }
  }

  if (activeDeck) {
    return (
      <DeckReview
        deck={activeDeck}
        onBack={() => setActiveDeckId(null)}
        onReview={(cardId, quality) => {
          reviewFlashcard(activeDeck.id, cardId, quality);
          if (quality >= 2) addXp(3, activeDeck.subject);
        }}
        onDelete={() => {
          if (confirm("Delete this deck?")) {
            deleteFlashcardDeck(activeDeck.id);
            setActiveDeckId(null);
          }
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <Layers className="h-5 w-5" />
          <span className="text-sm font-medium uppercase tracking-wider">
            Active recall
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold">Flashcards</h1>
        <p className="text-muted-foreground max-w-2xl">
          Generate a deck on any topic, then review with spaced repetition. Cards you
          struggle with come back sooner; ones you nail get pushed further out.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Make a new deck</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-4">
          <div className="space-y-2">
            <Label>Subject</Label>
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {subjectsForLevel.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Topic</Label>
            <Input
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Cell biology, the eye"
            />
          </div>
          <div className="space-y-2">
            <Label>Cards</Label>
            <Select value={String(count)} onValueChange={(v) => setCount(Number(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {COUNT_OPTIONS.map((c) => (
                  <SelectItem key={c} value={String(c)}>
                    {c} cards
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {error && (
            <div className="md:col-span-4 flex items-center gap-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4" />
              {error}
            </div>
          )}
          <div className="md:col-span-4 flex justify-end">
            <Button onClick={generate} disabled={generating}>
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Cooking up cards...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate deck
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-lg font-semibold mb-3">Your decks</h2>
        {decks.length === 0 ? (
          <Card>
            <CardContent className="py-10 text-center text-muted-foreground">
              No decks yet. Create one above.
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {decks.map((d) => {
              const dueCount = d.cards.filter((c) => c.due <= Date.now()).length;
              return (
                <motion.button
                  key={d.id}
                  whileHover={{ y: -2 }}
                  onClick={() => setActiveDeckId(d.id)}
                  className="text-left"
                >
                  <Card className="h-full hover:border-primary/50 transition-colors">
                    <CardContent className="pt-6 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs text-muted-foreground">{d.subject}</p>
                          <p className="font-semibold">{d.topic}</p>
                        </div>
                        <Layers className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <Badge variant="secondary">{d.cards.length} cards</Badge>
                        {dueCount > 0 && (
                          <Badge>{dueCount} due</Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function DeckReview({
  deck,
  onBack,
  onReview,
  onDelete,
}: {
  deck: FlashcardDeck;
  onBack: () => void;
  onReview: (cardId: string, quality: 0 | 1 | 2 | 3) => void;
  onDelete: () => void;
}) {
  const queue = useMemo(() => {
    const now = Date.now();
    const due = deck.cards.filter((c) => c.due <= now);
    return due.length > 0 ? due : deck.cards;
  }, [deck]);

  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const card = queue[index];
  const finished = !card;

  function rate(q: 0 | 1 | 2 | 3) {
    if (!card) return;
    onReview(card.id, q);
    setFlipped(false);
    setIndex((i) => i + 1);
  }

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ChevronLeft className="h-4 w-4 mr-1" />
          Decks
        </Button>
        <Button variant="ghost" size="sm" onClick={onDelete}>
          <Trash2 className="h-4 w-4 mr-1" />
          Delete
        </Button>
      </div>

      <div className="text-center space-y-1">
        <p className="text-xs text-muted-foreground">{deck.subject}</p>
        <h1 className="text-2xl font-bold">{deck.topic}</h1>
        <p className="text-xs text-muted-foreground">
          {finished ? "Session complete" : `Card ${index + 1} of ${queue.length}`}
        </p>
      </div>

      {finished ? (
        <Card>
          <CardContent className="py-12 text-center space-y-4">
            <p className="text-lg">Nicely done. Come back tomorrow for the next round.</p>
            <Button
              onClick={() => {
                setIndex(0);
                setFlipped(false);
              }}
            >
              <RotateCw className="h-4 w-4 mr-2" />
              Run through again
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <motion.div
            key={card.id + (flipped ? "-back" : "-front")}
            initial={{ rotateY: flipped ? -90 : 90, opacity: 0 }}
            animate={{ rotateY: 0, opacity: 1 }}
            transition={{ duration: 0.25 }}
            onClick={() => setFlipped((v) => !v)}
            className="cursor-pointer"
          >
            <Card className="min-h-[320px] hover:border-primary/40">
              <CardContent className="py-12 px-6 flex flex-col items-center justify-center text-center min-h-[320px]">
                <p className="text-xs uppercase tracking-wider text-muted-foreground mb-4">
                  {flipped ? "Answer" : "Question"}
                </p>
                <p className="text-xl md:text-2xl font-medium leading-relaxed whitespace-pre-line">
                  {flipped ? card.back : card.front}
                </p>
                {!flipped && card.hint && (
                  <p className="mt-6 text-sm text-muted-foreground italic">
                    Hint: {card.hint}
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {!flipped ? (
            <div className="flex justify-center">
              <Button onClick={() => setFlipped(true)}>Show answer</Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              <Button variant="outline" onClick={() => rate(0)}>
                Forgot
              </Button>
              <Button variant="outline" onClick={() => rate(1)}>
                Hard
              </Button>
              <Button variant="outline" onClick={() => rate(2)}>
                Good
              </Button>
              <Button onClick={() => rate(3)}>Easy</Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
