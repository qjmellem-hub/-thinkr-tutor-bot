import { useState } from "react";
import { useProfile, useStore, Profile, EducationCategory } from "@/lib/store";
import { EDUCATION_CATEGORIES, GRADES, LANGUAGES, TEACHING_STYLES, SUBJECTS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { ArrowRight, BookOpen, Sparkles, Flame, Target, MessageSquare } from "lucide-react";
import { Progress } from "@/components/ui/progress";

function Onboarding() {
  const updateProfile = useStore(state => state.updateProfile);
  const [step, setStep] = useState(1);
  const [data, setData] = useState<Partial<Profile>>({
    name: "",
    category: "",
    level: "",
    language: "English",
    teachingStyle: "Friendly"
  });

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      updateProfile({ ...data, hasOnboarded: true } as Profile);
    }
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center p-4">
      <div className="w-full max-w-lg space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
        <div className="text-center space-y-2">
          <div className="mx-auto bg-primary/10 text-primary p-3 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
            <BookOpen className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Welcome to Thinkr</h1>
          <p className="text-muted-foreground text-lg">Your personal study companion.</p>
        </div>

        <Card className="border-none shadow-xl bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-lg">What should I call you?</Label>
                  <Input 
                    id="name" 
                    placeholder="Your name..." 
                    className="text-lg py-6"
                    value={data.name}
                    onChange={(e) => setData({ ...data, name: e.target.value })}
                  />
                </div>
                <Button 
                  size="lg" 
                  className="w-full text-lg h-14" 
                  onClick={handleNext}
                  disabled={!data.name?.trim()}
                >
                  Continue <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="space-y-4">
                  <Label className="text-lg">What phase are you in?</Label>
                  <div className="grid gap-3">
                    {EDUCATION_CATEGORIES.map(cat => (
                      <Button
                        key={cat.value}
                        variant={data.category === cat.value ? "default" : "outline"}
                        className="justify-start h-16 text-base"
                        onClick={() => setData({ ...data, category: cat.value as EducationCategory, level: "" })}
                      >
                        {cat.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {data.category && (
                  <div className="space-y-4 animate-in fade-in">
                    <Label className="text-lg">Which specific level?</Label>
                    <Select value={data.level} onValueChange={(val) => setData({ ...data, level: val })}>
                      <SelectTrigger className="h-14 text-lg">
                        <SelectValue placeholder="Select your grade or level" />
                      </SelectTrigger>
                      <SelectContent>
                        {GRADES[data.category as EducationCategory].map(grade => (
                          <SelectItem key={grade} value={grade}>{grade}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button variant="ghost" size="lg" className="h-14" onClick={() => setStep(1)}>Back</Button>
                  <Button 
                    size="lg" 
                    className="flex-1 text-lg h-14" 
                    onClick={handleNext}
                    disabled={!data.category || !data.level}
                  >
                    Continue <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="space-y-4">
                  <Label className="text-lg">What language do you prefer to learn in?</Label>
                  <Select value={data.language} onValueChange={(val) => setData({ ...data, language: val })}>
                    <SelectTrigger className="h-14 text-lg">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGES.map(lang => (
                        <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button variant="ghost" size="lg" className="h-14" onClick={() => setStep(2)}>Back</Button>
                  <Button 
                    size="lg" 
                    className="flex-1 text-lg h-14" 
                    onClick={handleNext}
                    disabled={!data.language}
                  >
                    Continue <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                <div className="space-y-4">
                  <Label className="text-lg">How do you want me to teach you?</Label>
                  <div className="grid gap-3">
                    {TEACHING_STYLES.map(style => (
                      <div 
                        key={style.value}
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          data.teachingStyle === style.value 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                        onClick={() => setData({ ...data, teachingStyle: style.value })}
                      >
                        <div className="font-semibold text-lg mb-1">{style.label}</div>
                        <div className="text-sm text-muted-foreground">{style.description}</div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button variant="ghost" size="lg" className="h-14" onClick={() => setStep(3)}>Back</Button>
                  <Button 
                    size="lg" 
                    className="flex-1 text-lg h-14" 
                    onClick={handleNext}
                    disabled={!data.teachingStyle}
                  >
                    Start Studying <Sparkles className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function Home() {
  const profile = useProfile();
  const store = useStore();

  if (!profile.hasOnboarded) {
    return <Onboarding />;
  }

  // Get active subjects from progress
  const activeSubjects = Object.keys(store.progress).filter(subject => store.progress[subject].xp > 0);

  return (
    <div className="space-y-8 pb-8 animate-in fade-in">
      <header className="space-y-2">
        <h1 className="text-4xl font-bold tracking-tight">Hey, {profile.name}!</h1>
        <p className="text-lg text-muted-foreground">Ready to crush it today? Let's get studying.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-500" /> Current Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{store.currentStreak} Days</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> Total XP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{store.totalXp}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Target className="w-4 h-4 text-blue-500" /> Daily Goal
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-xl font-bold">In Progress</div>
            <Progress value={Math.min(100, (store.sessions.filter(s => new Date(s.timestamp).toDateString() === new Date().toDateString()).length / 3) * 100)} />
          </CardContent>
        </Card>
      </div>

      <div className="bg-card rounded-2xl p-8 border text-center space-y-6 shadow-sm">
        <div className="mx-auto bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center">
          <MessageSquare className="w-10 h-10 text-primary" />
        </div>
        <div className="space-y-2 max-w-md mx-auto">
          <h2 className="text-2xl font-semibold">Start a new session</h2>
          <p className="text-muted-foreground">Got a test coming up? Stuck on homework? Let's tackle it together.</p>
        </div>
        <Link href="/chat">
          <Button size="lg" className="h-14 px-8 text-lg rounded-full shadow-lg shadow-primary/20 hover:shadow-primary/30 hover:-translate-y-0.5 transition-all">
            Start Studying <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </Link>
      </div>

      {activeSubjects.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Continue Studying</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {activeSubjects.map(subject => {
              const prog = store.progress[subject];
              return (
                <Link key={subject} href={`/chat?subject=${encodeURIComponent(subject)}`}>
                  <Card className="hover:border-primary/50 transition-colors cursor-pointer group">
                    <CardHeader>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">{subject}</CardTitle>
                      <CardDescription>Mastery: {Math.round(prog.mastery)}%</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Progress value={prog.mastery} className="h-2" />
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
