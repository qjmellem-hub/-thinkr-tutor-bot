import { useMemo, useState } from "react";
import { useStore, useProfile, type PastPaperAttempt } from "@/lib/store";
import { API_BASE, SUBJECTS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  ScrollText,
  Loader2,
  Sparkles,
  CheckCircle2,
  Lightbulb,
  AlertCircle,
  RotateCcw,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { v4 as uuidv4 } from "uuid";
import { motion, AnimatePresence } from "framer-motion";

const MARK_OPTIONS = [4, 6, 8, 10, 15, 20];

export default function PastPapers() {
  const profile = useProfile();
  const addPastPaperAttempt = useStore((s) => s.addPastPaperAttempt);
  const updatePastPaperAttempt = useStore((s) => s.updatePastPaperAttempt);
  const addXp = useStore((s) => s.addXp);
  const addSession = useStore((s) => s.addSession);
  const attempts = useStore((s) => s.pastPaperAttempts);

  const subjectsForLevel = useMemo<string[]>(() => {
    if (profile.category === "Tertiary") return ["My module"];
    return (
      SUBJECTS[profile.category as "Foundation/Intermediate" | "Senior/FET"] ?? [
        "Mathematics",
      ]
    );
  }, [profile.category]);

  const [subject, setSubject] = useState<string>(subjectsForLevel[0] ?? "Mathematics");
  const [topic, setTopic] = useState("");
  const [marks, setMarks] = useState<number>(6);
  const [generating, setGenerating] = useState(false);
  const [grading, setGrading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState<PastPaperAttempt | null>(null);
  const [studentAnswer, setStudentAnswer] = useState("");
  const [showModelAnswer, setShowModelAnswer] = useState(false);

  async function generate() {
    setError(null);
    setGenerating(true);
    setShowModelAnswer(false);
    setStudentAnswer("");
    try {
      const res = await fetch(`${API_BASE}/chat/past-paper`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject,
          level: profile.level,
          topic: topic.trim() || undefined,
          language: profile.language,
          marks,
        }),
      });
      if (!res.ok) throw new Error("Could not generate question");
      const data = await res.json();
      const attempt: PastPaperAttempt = {
        id: uuidv4(),
        timestamp: Date.now(),
        subject,
        level: profile.level,
        topic: topic.trim() || "Mixed",
        language: profile.language,
        question: data.question,
        marks: data.marks,
        markScheme: data.markScheme,
        modelAnswer: data.modelAnswer,
        tips: data.tips,
      };
      setActive(attempt);
      addPastPaperAttempt(attempt);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setGenerating(false);
    }
  }

  async function gradeAnswer() {
    if (!active) return;
    if (!studentAnswer.trim()) {
      setError("Write your answer first.");
      return;
    }
    setError(null);
    setGrading(true);
    try {
      const res = await fetch(`${API_BASE}/chat/grade-answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: active.subject,
          level: active.level,
          language: active.language,
          question: active.question,
          markScheme: active.markScheme,
          marks: active.marks,
          studentAnswer,
        }),
      });
      if (!res.ok) throw new Error("Could not grade your answer");
      const data = await res.json();
      const updated: PastPaperAttempt = {
        ...active,
        studentAnswer,
        marksAwarded: data.marksAwarded,
        feedback: data.feedback,
        strengths: data.strengths,
        improvements: data.improvements,
      };
      setActive(updated);
      updatePastPaperAttempt(active.id, updated);
      const earned = Math.round((data.marksAwarded / active.marks) * 30) + 10;
      addXp(earned, active.subject);
      addSession({
        id: uuidv4(),
        timestamp: Date.now(),
        subject: active.subject,
        topic: `Past paper: ${active.topic}`,
        durationMinutes: Math.max(5, Math.round(active.marks * 1.5)),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setGrading(false);
    }
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <ScrollText className="h-5 w-5" />
          <span className="text-sm font-medium uppercase tracking-wider">
            Exam practice
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold">Past papers</h1>
        <p className="text-muted-foreground max-w-2xl">
          Generate exam-style questions in CAPS style, write your answer, and have it
          marked with feedback like a real teacher would.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Set up a question</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-4">
          <div className="space-y-2 md:col-span-1">
            <Label>Subject</Label>
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {subjectsForLevel.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Topic (optional)</Label>
            <Input
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Trigonometric identities"
            />
          </div>
          <div className="space-y-2">
            <Label>Marks</Label>
            <Select
              value={String(marks)}
              onValueChange={(v) => setMarks(Number(v))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MARK_OPTIONS.map((m) => (
                  <SelectItem key={m} value={String(m)}>
                    {m} marks
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-4 flex justify-end">
            <Button onClick={generate} disabled={generating}>
              {generating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Drafting question...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate exam question
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive">
          <AlertCircle className="h-4 w-4" />
          {error}
        </div>
      )}

      <AnimatePresence mode="wait">
        {active && (
          <motion.div
            key={active.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            <Card>
              <CardHeader className="flex flex-row items-start justify-between gap-4">
                <div>
                  <CardTitle className="text-lg">
                    {active.subject} · {active.topic}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {active.level} · Worth {active.marks} marks
                  </p>
                </div>
                <Badge variant="secondary">{active.marks} marks</Badge>
              </CardHeader>
              <CardContent className="prose prose-sm max-w-none dark:prose-invert">
                <ReactMarkdown>{active.question}</ReactMarkdown>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Your answer</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  rows={10}
                  value={studentAnswer}
                  onChange={(e) => setStudentAnswer(e.target.value)}
                  placeholder="Write your answer here. Show your reasoning step by step."
                  disabled={active.marksAwarded !== undefined}
                />
                <div className="flex flex-wrap gap-2 justify-end">
                  <Button
                    variant="ghost"
                    onClick={() => setShowModelAnswer((v) => !v)}
                  >
                    {showModelAnswer ? "Hide" : "Reveal"} model answer
                  </Button>
                  {active.marksAwarded === undefined ? (
                    <Button onClick={gradeAnswer} disabled={grading}>
                      {grading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Marking...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Mark my answer
                        </>
                      )}
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setActive(null);
                        setStudentAnswer("");
                      }}
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Try a new question
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {showModelAnswer && (
              <Card className="border-primary/30 bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-primary" />
                    Model answer & mark scheme
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 prose prose-sm max-w-none dark:prose-invert">
                  <h4>Mark scheme</h4>
                  <ReactMarkdown>{active.markScheme}</ReactMarkdown>
                  <h4>Model answer</h4>
                  <ReactMarkdown>{active.modelAnswer}</ReactMarkdown>
                  {active.tips && (
                    <>
                      <h4>Exam tip</h4>
                      <ReactMarkdown>{active.tips}</ReactMarkdown>
                    </>
                  )}
                </CardContent>
              </Card>
            )}

            {active.marksAwarded !== undefined && (
              <motion.div
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <Card className="border-primary/40">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>Your marks</span>
                      <span className="text-3xl font-bold text-primary">
                        {active.marksAwarded}/{active.marks}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <ReactMarkdown>{active.feedback ?? ""}</ReactMarkdown>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <h4 className="font-medium mb-2 text-sm">What worked</h4>
                        <ul className="space-y-1 text-sm">
                          {(active.strengths ?? []).map((s, i) => (
                            <li key={i} className="flex gap-2">
                              <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                              <span>{s}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2 text-sm">To improve</h4>
                        <ul className="space-y-1 text-sm">
                          {(active.improvements ?? []).map((s, i) => (
                            <li key={i} className="flex gap-2">
                              <Lightbulb className="h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
                              <span>{s}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {!active && attempts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent attempts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {attempts.slice(0, 6).map((a) => (
              <button
                key={a.id}
                onClick={() => {
                  setActive(a);
                  setStudentAnswer(a.studentAnswer ?? "");
                }}
                className="w-full text-left p-3 rounded-lg border hover:bg-muted transition-colors"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-medium truncate">
                      {a.subject} · {a.topic}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {a.question.slice(0, 90)}...
                    </div>
                  </div>
                  <Badge variant={a.marksAwarded !== undefined ? "default" : "secondary"}>
                    {a.marksAwarded !== undefined
                      ? `${a.marksAwarded}/${a.marks}`
                      : `${a.marks} marks`}
                  </Badge>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
