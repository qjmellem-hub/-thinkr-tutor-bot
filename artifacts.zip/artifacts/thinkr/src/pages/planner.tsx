import { useMemo, useState } from "react";
import { useStore, useProfile, type StudyPlan } from "@/lib/store";
import { API_BASE, SUBJECTS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CalendarClock,
  Sparkles,
  Loader2,
  AlertCircle,
  Clock,
  Trash2,
} from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import { motion } from "framer-motion";

const DAY_OPTIONS = [3, 7, 14, 21, 30];
const MIN_OPTIONS = [30, 45, 60, 90, 120];

export default function Planner() {
  const profile = useProfile();
  const studyPlan = useStore((s) => s.studyPlan);
  const setStudyPlan = useStore((s) => s.setStudyPlan);
  const togglePlannerBlock = useStore((s) => s.togglePlannerBlock);
  const addXp = useStore((s) => s.addXp);

  const subjectsForLevel = useMemo<string[]>(() => {
    if (profile.category === "Tertiary") return ["My module"];
    return (
      SUBJECTS[profile.category as "Foundation/Intermediate" | "Senior/FET"] ?? [
        "Mathematics",
      ]
    );
  }, [profile.category]);

  const [selected, setSelected] = useState<string[]>(subjectsForLevel.slice(0, 3));
  const [days, setDays] = useState<number>(7);
  const [minutes, setMinutes] = useState<number>(60);
  const [goals, setGoals] = useState("");
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const completion = useMemo(() => {
    if (!studyPlan) return { done: 0, total: 0, pct: 0 };
    let done = 0;
    let total = 0;
    studyPlan.days.forEach((d) =>
      d.blocks.forEach((b) => {
        total += 1;
        if (b.done) done += 1;
      }),
    );
    return { done, total, pct: total === 0 ? 0 : Math.round((done / total) * 100) };
  }, [studyPlan]);

  function toggleSubject(s: string) {
    setSelected((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s],
    );
  }

  async function generate() {
    if (selected.length === 0) {
      setError("Pick at least one subject.");
      return;
    }
    setError(null);
    setGenerating(true);
    try {
      const res = await fetch(`${API_BASE}/chat/study-plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subjects: selected,
          level: profile.level,
          language: profile.language,
          daysUntilExam: days,
          minutesPerDay: minutes,
          goals: goals.trim() || undefined,
        }),
      });
      if (!res.ok) throw new Error("Could not build a plan");
      const data = await res.json();
      const plan: StudyPlan = {
        id: uuidv4(),
        createdAt: Date.now(),
        level: profile.level,
        language: profile.language,
        subjects: selected,
        goals,
        daysUntilExam: days,
        minutesPerDay: minutes,
        summary: data.summary ?? "",
        days: (data.days ?? []).map((d: {
          day?: number;
          date?: string;
          focus?: string;
          blocks?: { subject?: string; topic?: string; minutes?: number; activity?: string }[];
        }, i: number) => ({
          day: Number(d.day) || i + 1,
          date: String(d.date ?? ""),
          focus: String(d.focus ?? ""),
          blocks: (d.blocks ?? []).map((b) => ({
            subject: String(b.subject ?? ""),
            topic: String(b.topic ?? ""),
            minutes: Number(b.minutes) || 30,
            activity: String(b.activity ?? ""),
            done: false,
          })),
        })),
      };
      setStudyPlan(plan);
      addXp(20, selected[0] ?? "Study");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setGenerating(false);
    }
  }

  function discardPlan() {
    if (confirm("Discard this study plan?")) setStudyPlan(null);
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <CalendarClock className="h-5 w-5" />
          <span className="text-sm font-medium uppercase tracking-wider">
            Study planner
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold">Your study plan</h1>
        <p className="text-muted-foreground max-w-2xl">
          Tell Thinkr how much time you have and which subjects matter, and it builds a
          realistic day-by-day plan you can actually follow.
        </p>
      </header>

      {!studyPlan && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Build a plan</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label>How many days do you want to study?</Label>
              <Select
                value={String(days)}
                onValueChange={(v) => setDays(Number(v))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DAY_OPTIONS.map((d) => (
                    <SelectItem key={d} value={String(d)}>
                      {d} days
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Minutes per day</Label>
              <Select
                value={String(minutes)}
                onValueChange={(v) => setMinutes(Number(v))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MIN_OPTIONS.map((m) => (
                    <SelectItem key={m} value={String(m)}>
                      {m} minutes
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label>Subjects to focus on</Label>
              <div className="flex flex-wrap gap-2">
                {subjectsForLevel.map((s) => (
                  <button
                    key={s}
                    onClick={() => toggleSubject(s)}
                    className={`px-3 py-1.5 rounded-full border text-sm transition-colors ${
                      selected.includes(s)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "hover:bg-muted"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label>What are you working towards? (optional)</Label>
              <Textarea
                rows={3}
                placeholder="e.g. November prelim exams, Maths Paper 2 specifically"
                value={goals}
                onChange={(e) => setGoals(e.target.value)}
              />
            </div>

            {error && (
              <div className="md:col-span-2 flex items-center gap-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            )}

            <div className="md:col-span-2 flex justify-end">
              <Button onClick={generate} disabled={generating}>
                {generating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Building your plan...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Build my study plan
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {studyPlan && (
        <>
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-6 space-y-4">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">
                    {studyPlan.subjects.join(" · ")} · {studyPlan.minutesPerDay} min/day
                  </p>
                  <p className="text-base">{studyPlan.summary}</p>
                </div>
                <Button variant="ghost" size="sm" onClick={discardPlan}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Discard
                </Button>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Plan progress</span>
                  <span>
                    {completion.done}/{completion.total} blocks
                  </span>
                </div>
                <Progress value={completion.pct} />
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            {studyPlan.days.map((d, di) => (
              <motion.div
                key={di}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: di * 0.04 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center justify-between">
                      <span>
                        Day {d.day}
                        <span className="text-muted-foreground font-normal text-sm ml-2">
                          {d.date}
                        </span>
                      </span>
                      <span className="text-sm text-muted-foreground font-normal">
                        {d.focus}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {d.blocks.map((b, bi) => (
                      <label
                        key={bi}
                        className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                          b.done
                            ? "bg-primary/5 border-primary/30"
                            : "hover:bg-muted"
                        }`}
                      >
                        <Checkbox
                          checked={b.done}
                          onCheckedChange={() => {
                            togglePlannerBlock(di, bi);
                            if (!b.done) addXp(5, b.subject);
                          }}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-3">
                            <span className={`font-medium text-sm ${b.done ? "line-through text-muted-foreground" : ""}`}>
                              {b.subject} · {b.topic}
                            </span>
                            <span className="text-xs text-muted-foreground flex items-center gap-1 flex-shrink-0">
                              <Clock className="h-3 w-3" />
                              {b.minutes} min
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {b.activity}
                          </p>
                        </div>
                      </label>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
