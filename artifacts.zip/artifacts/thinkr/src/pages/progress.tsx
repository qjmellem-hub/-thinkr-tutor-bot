import { useStore, useProfile } from "@/lib/store";
import { BADGE_DETAILS } from "@/lib/constants";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import * as LucideIcons from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

export default function ProgressPage() {
  const store = useStore();
  const profile = useProfile();

  const subjects = Object.keys(store.progress);
  
  // Transform data for the bar chart
  const masteryData = subjects.map(sub => ({
    name: sub.length > 15 ? sub.substring(0, 15) + '...' : sub,
    full_name: sub,
    mastery: Math.round(store.progress[sub].mastery),
    xp: store.progress[sub].xp
  }));

  return (
    <div className="space-y-8 animate-in fade-in">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Your Progress</h1>
        <p className="text-muted-foreground">Keep pushing! Every session counts.</p>
      </header>

      {subjects.length === 0 ? (
        <Card className="text-center p-12 border-dashed">
          <div className="mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
            <LucideIcons.TrendingUp className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No progress yet</h3>
          <p className="text-muted-foreground mb-6">Start a study session to begin tracking your mastery.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="col-span-1 lg:col-span-2">
            <CardHeader>
              <CardTitle>Subject Mastery</CardTitle>
              <CardDescription>Your understanding across all active subjects</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={masteryData} layout="vertical" margin={{ left: 50, right: 20 }}>
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-popover border shadow-md p-3 rounded-lg">
                            <p className="font-semibold">{payload[0].payload.full_name}</p>
                            <p className="text-primary font-medium">{payload[0].value}% Mastery</p>
                            <p className="text-muted-foreground text-sm">{payload[0].payload.xp} XP earned</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="mastery" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={24} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Subject Breakdown</h3>
            <div className="space-y-4">
              {subjects.map(subject => {
                const prog = store.progress[subject];
                const lastStudied = new Date(prog.lastStudied).toLocaleDateString();
                
                return (
                  <Card key={subject}>
                    <CardContent className="p-5 space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-semibold text-lg">{subject}</h4>
                          <p className="text-sm text-muted-foreground">Last studied: {lastStudied}</p>
                        </div>
                        <Badge variant="secondary" className="font-mono">{prog.xp} XP</Badge>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Mastery</span>
                          <span className="font-medium">{Math.round(prog.mastery)}%</span>
                        </div>
                        <Progress value={prog.mastery} className="h-2.5 bg-secondary" />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Trophy Cabinet</h3>
            <Card>
              <CardContent className="p-6">
                {store.badges.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    Keep studying to unlock your first badge!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {Object.keys(BADGE_DETAILS).map(badgeName => {
                      const hasBadge = store.badges.includes(badgeName);
                      const details = BADGE_DETAILS[badgeName as keyof typeof BADGE_DETAILS];
                      const Icon = (LucideIcons as any)[details.icon] || LucideIcons.Award;
                      
                      return (
                        <div 
                          key={badgeName} 
                          className={`flex flex-col items-center text-center p-4 rounded-xl border-2 transition-all ${
                            hasBadge ? 'bg-primary/5 border-primary/20' : 'opacity-40 grayscale border-dashed'
                          }`}
                        >
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 ${
                            hasBadge ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-muted text-muted-foreground'
                          }`}>
                            <Icon className="w-6 h-6" />
                          </div>
                          <div className="font-semibold text-sm leading-tight mb-1">{badgeName}</div>
                          {hasBadge && (
                            <div className="text-[10px] text-muted-foreground">{details.description}</div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
