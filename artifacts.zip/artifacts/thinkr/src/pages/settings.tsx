import { useState } from "react";
import { useStore, useProfile, Profile, EducationCategory } from "@/lib/store";
import { EDUCATION_CATEGORIES, GRADES, LANGUAGES, TEACHING_STYLES } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Save, RefreshCcw, Info, Key, Eye, EyeOff, ExternalLink, Leaf } from "lucide-react";

export default function Settings() {
  const store = useStore();
  const profile = useProfile();
  const { toast } = useToast();

  const [formData, setFormData] = useState<Profile>(profile);
  const [showKey, setShowKey] = useState(false);

  const handleSave = () => {
    store.updateProfile(formData);
    toast({
      title: "Settings saved",
      description: "Your profile has been updated.",
    });
  };

  const handleReset = () => {
    store.resetProgress();
    toast({
      title: "Progress Reset",
      description: "Your account has been cleared. You will be redirected to onboarding.",
      variant: "destructive"
    });
    window.location.href = "/";
  };

  return (
    <div className="space-y-8 max-w-2xl animate-in fade-in pb-12">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your study preferences.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Profile Details</CardTitle>
          <CardDescription>These details help Thinkr personalize your experience.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Display Name</Label>
            <Input 
              id="name" 
              value={formData.name} 
              onChange={(e) => setFormData({ ...formData, name: e.target.value })} 
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Phase</Label>
              <Select 
                value={formData.category} 
                onValueChange={(val) => setFormData({ ...formData, category: val as EducationCategory, level: "" })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EDUCATION_CATEGORIES.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Level / Grade</Label>
              <Select 
                value={formData.level} 
                onValueChange={(val) => setFormData({ ...formData, level: val })}
                disabled={!formData.category}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  {formData.category && GRADES[formData.category as EducationCategory]?.map(grade => (
                    <SelectItem key={grade} value={grade}>{grade}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Instruction Language</Label>
              <Select 
                value={formData.language} 
                onValueChange={(val) => setFormData({ ...formData, language: val })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LANGUAGES.map(lang => (
                    <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Teaching Style</Label>
              <Select 
                value={formData.teachingStyle} 
                onValueChange={(val) => setFormData({ ...formData, teachingStyle: val })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TEACHING_STYLES.map(style => (
                    <SelectItem key={style.value} value={style.value}>{style.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleSave} className="w-full sm:w-auto">
            <Save className="w-4 h-4 mr-2" /> Save Changes
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" /> OpenAI API Key
          </CardTitle>
          <CardDescription>
            Optional. Use your own OpenAI API key for chats and image uploads.
            When set, your key powers the AI tutor and image analysis (vision).
            Leave blank to use the built-in free tutor.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="apiKey">API Key</Label>
            <div className="relative">
              <Input
                id="apiKey"
                type={showKey ? "text" : "password"}
                placeholder="sk-..."
                value={formData.apiKey}
                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                className="pr-10 font-mono text-sm"
                autoComplete="off"
              />
              <button
                type="button"
                onClick={() => setShowKey((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
                aria-label={showKey ? "Hide API key" : "Show API key"}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              Stored only on this device. Never shared.{" "}
              <a
                href="https://platform.openai.com/api-keys"
                target="_blank"
                rel="noreferrer"
                className="text-primary hover:underline inline-flex items-center gap-1"
              >
                Get a key <ExternalLink className="w-3 h-3" />
              </a>
            </p>
          </div>
          {formData.apiKey && (
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 text-xs text-muted-foreground">
              Your key will be used for chat replies and analyzing uploaded images
              (model: gpt-4o). Press <span className="font-medium text-foreground">Save Changes</span> below to apply.
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="w-5 h-5 text-primary" /> Data Saver Mode
          </CardTitle>
          <CardDescription>
            Built for SA mobile data. When on, Thinkr keeps things light: shorter AI replies,
            smaller image uploads, low-detail vision, less back-and-forth, and answers cached
            on your device so you don&apos;t pay twice for the same question.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start justify-between gap-4 p-3 rounded-lg border bg-muted/30">
            <div className="space-y-1">
              <Label htmlFor="dataSaver" className="text-base">
                Save data
              </Label>
              <p className="text-xs text-muted-foreground">
                {formData.dataSaver
                  ? "On — replies capped at ~120 words, images shrunk to 1024px JPEG @ 60%, max 1 image per message, foundations cached."
                  : "Off — full-length replies, up to 4 images @ 4MB each, no caching."}
              </p>
            </div>
            <Switch
              id="dataSaver"
              checked={formData.dataSaver}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, dataSaver: checked })
              }
            />
          </div>
          {formData.dataSaver && (
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 rounded-lg p-2.5">
                <p className="font-medium text-emerald-800 dark:text-emerald-200">
                  ~85% smaller
                </p>
                <p className="text-emerald-700/80 dark:text-emerald-300/80">
                  AI replies vs. default
                </p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 rounded-lg p-2.5">
                <p className="font-medium text-emerald-800 dark:text-emerald-200">
                  Up to 90% smaller
                </p>
                <p className="text-emerald-700/80 dark:text-emerald-300/80">
                  Image uploads after compression
                </p>
              </div>
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Tip: Replies will be very short while this is on. Turn it off on Wi-Fi for
            longer, more detailed explanations.
          </p>
        </CardContent>
      </Card>

      <Card className="border-destructive/20">
        <CardHeader>
          <CardTitle className="text-destructive">Danger Zone</CardTitle>
          <CardDescription>Irreversible actions for your account.</CardDescription>
        </CardHeader>
        <CardContent>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <RefreshCcw className="w-4 h-4 mr-2" /> Reset All Progress
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete your profile, all XP, badges, streaks, and chat history from this device.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleReset} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Yes, reset everything
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>

      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground pt-8">
        <Info className="w-4 h-4" />
        <span>Thinkr v1.0 — South African Edition</span>
      </div>
    </div>
  );
}
