import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, useProfile, type ChatMessage } from "@/lib/store";
import { API_BASE, SUBJECTS } from "@/lib/constants";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Bot,
  User,
  Headphones,
  AlertCircle,
} from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import { motion, AnimatePresence } from "framer-motion";

type SpeechRecognition = {
  start: () => void;
  stop: () => void;
  abort: () => void;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: { results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
};

const LANG_TO_BCP47: Record<string, string> = {
  English: "en-ZA",
  Afrikaans: "af-ZA",
  isiZulu: "zu-ZA",
  isiXhosa: "xh-ZA",
  Sesotho: "st-ZA",
  Setswana: "tn-ZA",
  Sepedi: "nso-ZA",
  Tshivenda: "ve-ZA",
  Xitsonga: "ts-ZA",
  siSwati: "ss-ZA",
  isiNdebele: "nr-ZA",
};

export default function Voice() {
  const profile = useProfile();
  const addXp = useStore((s) => s.addXp);
  const addSession = useStore((s) => s.addSession);

  const subjectsForLevel = useMemo<string[]>(() => {
    if (profile.category === "Tertiary") return ["My module"];
    return (
      SUBJECTS[profile.category as "Foundation/Intermediate" | "Senior/FET"] ?? [
        "Mathematics",
      ]
    );
  }, [profile.category]);

  const [subject, setSubject] = useState<string>(subjectsForLevel[0] ?? "Mathematics");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [partial, setPartial] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [supported, setSupported] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const recRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognition;
      webkitSpeechRecognition?: new () => SpeechRecognition;
    };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) {
      setSupported(false);
      return;
    }
    const rec = new Ctor();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = LANG_TO_BCP47[profile.language] ?? "en-ZA";
    rec.onresult = (e) => {
      let finalText = "";
      let interim = "";
      for (let i = 0; i < e.results.length; i += 1) {
        const r = e.results[i];
        if (r.isFinal) finalText += r[0].transcript;
        else interim += r[0].transcript;
      }
      setPartial(interim);
      if (finalText) {
        setPartial("");
        send(finalText.trim());
      }
    };
    rec.onend = () => setListening(false);
    rec.onerror = (e) => {
      setListening(false);
      if (e.error !== "aborted" && e.error !== "no-speech") {
        setError(`Microphone error: ${e.error}`);
      }
    };
    recRef.current = rec;
    return () => {
      rec.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile.language]);

  function startListening() {
    setError(null);
    if (!recRef.current) return;
    try {
      window.speechSynthesis?.cancel();
      setSpeaking(false);
      recRef.current.start();
      setListening(true);
    } catch {
      // ignore
    }
  }

  function stopListening() {
    recRef.current?.stop();
    setListening(false);
  }

  function speak(text: string) {
    if (!ttsEnabled) return;
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = LANG_TO_BCP47[profile.language] ?? "en-ZA";
    utter.rate = 1;
    utter.pitch = 1;
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(utter);
  }

  function stopSpeaking() {
    window.speechSynthesis?.cancel();
    setSpeaking(false);
  }

  async function send(text: string) {
    const userMsg: ChatMessage = {
      id: uuidv4(),
      role: "user",
      content: text,
      timestamp: Date.now(),
    };
    const next = [...messages, userMsg];
    setMessages(next);
    setStreaming(true);

    const placeholder: ChatMessage = {
      id: uuidv4(),
      role: "assistant",
      content: "",
      timestamp: Date.now(),
    };
    setMessages((m) => [...m, placeholder]);

    try {
      const res = await fetch(`${API_BASE}/chat/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: next.slice(-8).map((m) => ({ role: m.role, content: m.content })),
          subject,
          level: profile.level,
          teachingStyle: profile.teachingStyle,
          language: profile.language,
          studentName: profile.name,
        }),
      });
      if (!res.body) throw new Error("No response stream");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";
      // eslint-disable-next-line no-constant-condition
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const payload = line.slice(5).trim();
          if (!payload) continue;
          try {
            const json = JSON.parse(payload);
            if (json.content) {
              full += json.content;
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  content: full,
                };
                return copy;
              });
            }
            if (json.error) throw new Error(json.error);
          } catch {
            // partial line
          }
        }
      }
      addXp(15, subject);
      addSession({
        id: uuidv4(),
        timestamp: Date.now(),
        subject,
        topic: "Voice tutoring",
        durationMinutes: 5,
      });
      speak(full);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not get a response");
    } finally {
      setStreaming(false);
    }
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <Headphones className="h-5 w-5" />
          <span className="text-sm font-medium uppercase tracking-wider">
            Hands-free study
          </span>
        </div>
        <h1 className="text-3xl md:text-4xl font-bold">Voice tutor</h1>
        <p className="text-muted-foreground max-w-2xl">
          Tap the mic, ask your question out loud, and Thinkr replies in your home
          language. Perfect for revising on the bus or while walking.
        </p>
      </header>

      {!supported && (
        <Card className="border-amber-300 bg-amber-50 dark:bg-amber-950/20">
          <CardContent className="pt-6 flex gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0" />
            <div className="text-sm">
              Your browser does not support speech recognition. Try Chrome, Edge, or
              Safari, or use the text chat instead.
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-3">
          <div>
            <CardTitle className="text-lg">{subject}</CardTitle>
            <p className="text-xs text-muted-foreground">
              {profile.level} · {profile.language} · {profile.teachingStyle}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {subjectsForLevel.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTtsEnabled((v) => !v)}
              title={ttsEnabled ? "Mute voice replies" : "Unmute voice replies"}
            >
              {ttsEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col items-center justify-center py-8 gap-4">
            <motion.button
              onClick={listening ? stopListening : startListening}
              disabled={!supported || streaming}
              whileTap={{ scale: 0.95 }}
              animate={
                listening
                  ? { scale: [1, 1.08, 1], boxShadow: ["0 0 0 0 rgba(99,159,127,0.4)", "0 0 0 24px rgba(99,159,127,0)", "0 0 0 0 rgba(99,159,127,0)"] }
                  : {}
              }
              transition={
                listening ? { duration: 1.6, repeat: Infinity } : { duration: 0.2 }
              }
              className={`h-28 w-28 rounded-full flex items-center justify-center transition-colors ${
                listening
                  ? "bg-destructive text-destructive-foreground"
                  : "bg-primary text-primary-foreground"
              } disabled:opacity-50`}
            >
              {listening ? <MicOff className="h-10 w-10" /> : <Mic className="h-10 w-10" />}
            </motion.button>
            <p className="text-sm text-muted-foreground text-center max-w-sm">
              {listening
                ? "Listening... speak naturally, then pause."
                : speaking
                ? "Thinkr is speaking. Tap the mic to interrupt."
                : streaming
                ? "Thinkr is thinking..."
                : "Tap the mic to ask a question."}
            </p>
            {partial && (
              <p className="italic text-muted-foreground text-sm text-center">
                "{partial}"
              </p>
            )}
            {speaking && (
              <Button variant="outline" size="sm" onClick={stopSpeaking}>
                <VolumeX className="h-3 w-3 mr-2" />
                Stop talking
              </Button>
            )}
          </div>

          {error && (
            <div className="flex items-center gap-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4" />
              {error}
            </div>
          )}
        </CardContent>
      </Card>

      {messages.length > 0 && (
        <div className="space-y-3">
          <AnimatePresence initial={false}>
            {messages.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}
              >
                {m.role === "assistant" && (
                  <div className="h-8 w-8 rounded-full bg-primary/15 text-primary flex items-center justify-center flex-shrink-0">
                    <Bot className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`rounded-2xl px-4 py-3 max-w-[80%] text-sm ${
                    m.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  {m.content || (
                    <span className="opacity-60">Thinking...</span>
                  )}
                </div>
                {m.role === "user" && (
                  <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
